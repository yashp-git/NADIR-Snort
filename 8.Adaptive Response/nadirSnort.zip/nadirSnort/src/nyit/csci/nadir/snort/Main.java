package nyit.csci.nadir.snort;
import java.io.IOException;

public class Main {

	@SuppressWarnings({ "static-access" })
	public static void main(String[] args) throws IOException, InterruptedException {
	
		String new_rule ="temp/test.rules";
		String exist_rule ="/etc/snort/rules/my-snort.rules";					
		
//		compareRule compare = new compareRule();
//		compare.ruleCompare(new_rule, exist_rule);
//		
		pushRule push_rule = new pushRule();
		push_rule.push(new_rule, exist_rule);
		
		//snort service call
		snortService snortservice = new snortService();
		snortservice.reloadSnort();
	}
	

}
