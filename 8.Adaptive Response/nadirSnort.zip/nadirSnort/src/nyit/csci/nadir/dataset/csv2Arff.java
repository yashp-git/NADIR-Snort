package nyit.csci.nadir.dataset;

import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;
 
import java.io.File;
 
public class csv2Arff
{
 
	public static void Convert(String sourcepath,String destpath) throws Exception
	{
	 CSVLoader loader = new CSVLoader();
	    loader.setSource(new File(sourcepath));
	    Instances data = loader.getDataSet();

	    ArffSaver saver = new ArffSaver();
	    saver.setInstances(data);
	    saver.setFile(new File(destpath));
	    saver.writeBatch();
	}
}