package nyit.csci.nadir.dataset;

public class Main {

	public static void main(String[] args) throws Exception {
		String name = "java_rmi_4_15_17.pcap";
		int frame_loop =200000;
//		String input_log = "D://log//";
		String input_log = "/home/victim/log/";
		String output_raw = "Extract_csv/raw_csv/";
		String extract_path="Extract_csv/zextracted/";
		String final_extract ="Extract_csv/final_extracted_csv/";
		String split_path="Extract_csv/zsplit/";
		String arff_path="Extract_csv/final_extracted_arff/";
		long milisec=4000;
		
		
		pcap2Csv pcapparse = new pcap2Csv();
		pcapparse.pcap2csv(frame_loop,name, input_log, output_raw);
		
		extract2CSV extractcsv = new extract2CSV();
		extractcsv.extract2csv(name, output_raw, extract_path, split_path, arff_path, final_extract, milisec);
		
		
	}

}
