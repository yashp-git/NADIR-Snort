package nyit.csci.nadir.snort;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class dropMain {

	public static void main(String[] args) throws IOException, InterruptedException {
		
//		String snort_log ="temp/snort.txt";
//		String drop_rule ="temp/my-drop.rules";
//		
		String snort_log ="/var/log/snort/snort.txt";
		String drop_rule ="/etc/snort/rules/my-drop.rules";
		
		
		dropRule rule = new dropRule();
		rule.ruleDrop(snort_log,drop_rule);
		
		trimfile(drop_rule);
	    
		//snort service call
	    snortService snortservice = new snortService();
		snortservice.reloadSnort();
		System.out.println("[*]Done");

	}
	
	
public static void trimfile(String filename) throws IOException{
		
		System.out.println("[*] Generating Drop Rules");
		BufferedReader reader = new BufferedReader(new FileReader(filename));
	    Set<String> lines = new HashSet<String>(100000); // maybe should be bigger
	    String line;
	    while ((line = reader.readLine()) != null) {
	        	        lines.add(line);
	    }
	    reader.close();
	    BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
	    BufferedReader sid = new BufferedReader(new FileReader("temp/dropsid.txt"));
	    String s = "";
	    int i;
	    
	    if(sid.readLine()!=null){
	    s = sid.readLine();
	    i= Integer.parseInt(s);
	    }
	    else{
	    	s = "4000";
		    i= Integer.parseInt(s);
	    }
	    
	    for (String unique : lines) {
	    	//System.out.println(unique);
	    	writer.write(unique+i+"; )");
	        i++;
	        writer.newLine();
	    }
	    BufferedWriter fw = new BufferedWriter(new FileWriter("temp/dropsid.txt"));
		//System.out.println(i-1);
		fw.write((i-1)+"");;
		fw.close();
	    
	    writer.close();
	}
	

}
