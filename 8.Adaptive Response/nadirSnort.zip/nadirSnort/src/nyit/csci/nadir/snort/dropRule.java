package nyit.csci.nadir.snort;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class dropRule {

	public static void ruleDrop(String file1,String file2) throws IOException{
		try (BufferedReader br = new BufferedReader(new FileReader(file1))) {
		    
			String line = null;
			String drop ="attack-detected on";
			String regex ="(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
		    
			Pattern drop_pattern = Pattern.compile(drop);
			Pattern pattern = Pattern.compile(regex);
			//int sid = 3000;
			
		    while ((line = br.readLine()) != null) {
		    	//System.out.println(line);
		    	
		    	Matcher matcher = drop_pattern.matcher(line);
		    	Matcher ip_matcher = pattern.matcher(line);
		    	
		    	if (matcher.find() && ip_matcher.find()) {
			        //System.out.println(matcher.group(0)+" "+ip_matcher.group(0));
		    		
		    		String ip = ip_matcher.group(0);
			        try(FileWriter fw = new FileWriter(file2, true);
		            	    BufferedWriter bw = new BufferedWriter(fw);
		            	    PrintWriter out = new PrintWriter(bw))
		            	{
		            	    //out.print(line+"\n");
			        		out.println("drop tcp "+ip+" any -> $HOME_NET any (msg: \"drop connection for "+ip+" \"; sid: ");
		            	    //System.out.println("[*]drop rule generated");
		            	    //sid++;
		            	    
		            	} catch (IOException e) {
		            	    //exception handling left as an exercise for the reader
		            	}
			        
			    } else {
			       // System.out.println("[*]ip not found");
			    }
		    	
		    	
		    }
		}
	}
}
