package nyit.csci.nadir.weka;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

public class TestModel {

	public static void main(String[] args) throws IOException {
	
		//String command = "-t \"Extract_csv/final_extracted_arff/Final_Extracted_merged_normal_nmap_dos_R2L_training_set.csv_4000.csv.arff\"\n-T \"Extract_csv/final_extracted_arff/Final_Extracted_merged_normal_nmap_dos_R2L_testing_dataset.csv_4000.csv.arff\"";
		TrainModel wekarun = new TrainModel();
		wekarun.runClassifier(new TrainModel(), args);
		    
		    trimfile("temp/test.rules");
		    System.out.println("[*]Done");
		   	    
	}
	
	public static void trimfile(String filename) throws IOException{
		
		System.out.println("[*]Generating Snort Rules");
		BufferedReader reader = new BufferedReader(new FileReader(filename));
	    Set<String> lines = new HashSet<String>(100000); // maybe should be bigger
	    String line;
	    while ((line = reader.readLine()) != null) {
	        	        lines.add(line);
	    }
	    reader.close();
	    BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
	    BufferedReader sid = new BufferedReader(new FileReader("temp/sid.txt"));
	    String s = "";
	    int i;
	    
	    if(sid.readLine()!=null){
	    s = sid.readLine();
	    i= Integer.parseInt(s);
	    }	
	    else{
	    	s = "3000";
		    i= Integer.parseInt(s);
	    }
	    
	    for (String unique : lines) {
	    	//System.out.println(unique);
	    	writer.write(unique+i+"; )");
	        i++;
	        writer.newLine();
	    }
	    BufferedWriter fw = new BufferedWriter(new FileWriter("temp/sid.txt"));
		//System.out.println(i-1);
		fw.write((i-1)+"");;
		fw.close();
	    
	    writer.close();
	}

	
}

