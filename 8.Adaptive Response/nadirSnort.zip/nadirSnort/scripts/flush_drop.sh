#!/bin/bash
truncate -s 0 /etc/snort/rules/my-drop.rules
truncate -s 0 /home/victim/workspace/nadirSnort/temp/dropsid.txt
