package nyit.csci.nadir.dataset;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main2Mergecsv {

	public static void main(String[] args) throws IOException {
		String file1="merged_nmap_dos_ddos_R2L_train_dataset.csv";
		String file2="Final_Extracted_java_rmi_4_15_17_2.pcap_4000.csv";
	    
		List<Path> paths = Arrays.asList(Paths.get("Extract_csv/final/"+file1), Paths.get("Extract_csv/final_extracted_csv/"+file2));
	    List<String> mergedLines = getMergedLines(paths);
	    Path target = Paths.get("Extract_csv/final/merged_nmap_dos_ddos_R2L_train_dataset.csv");
	    Files.write(target, mergedLines, Charset.forName("UTF-8"));
	}

	private static List<String> getMergedLines(List<Path> paths) throws IOException {
	    List<String> mergedLines = new ArrayList<> ();
	    for (Path p : paths){
	        List<String> lines = Files.readAllLines(p, Charset.forName("UTF-8"));
	        if (!lines.isEmpty()) {
	            if (mergedLines.isEmpty()) {
	                mergedLines.add(lines.get(0)); //add header only once
	            }
	            mergedLines.addAll(lines.subList(1, lines.size()));
	        }
	    }
	    System.out.println("[*]Done...");
	    return mergedLines;
	}
	
}