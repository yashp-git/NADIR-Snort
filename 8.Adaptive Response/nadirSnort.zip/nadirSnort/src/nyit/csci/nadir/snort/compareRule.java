package nyit.csci.nadir.snort;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class compareRule {

	public static void ruleCompare(String file1,String file2) throws IOException, InterruptedException
    {    
        BufferedReader reader1 = new BufferedReader(new FileReader(file1));
         
        BufferedReader reader2 = new BufferedReader(new FileReader(file2));
         
        String line1 = reader1.readLine();
         
        String line2 = reader2.readLine();
         
        boolean areEqual = true;
         
        int lineNum = 1;
         
        while (line1 != null || line2 != null)
        {
            if(line1 == null || line2 == null)
            {
                areEqual = false;
                 
                break;
            }
            else if(! line1.equalsIgnoreCase(line2))
            {
                areEqual = false;
                 
                break;
            }
             
            line1 = reader1.readLine();
             
            line2 = reader2.readLine();
             
            lineNum++;
        }
         
        if(areEqual)
        {
            System.out.println("[*]Two files have same rules.");
           
        }
        else
        {
            System.out.println("[*]Two files have different rules. They differ at line "+lineNum);
            System.out.println("[*]New rule :- "+line1);
            
            try(FileWriter fw = new FileWriter(file2, true);
            	    BufferedWriter bw = new BufferedWriter(fw);
            	    PrintWriter out = new PrintWriter(bw))
            	{
            	    out.print(line1+"\n");
            	    
            	} catch (IOException e) {
            	    //exception handling left as an exercise for the reader
            	}
                      
          //snort service call
            snortService snortservice = new snortService();
    		snortservice.reloadSnort();
        }
         
        reader1.close();
         
        reader2.close();
        
    }

}
