package nyit.csci.nadir.dataset;

import java.io.File;

public class printMain {
	public static void main(String args[]){
		File folder = new File("Extract_csv/final_extracted_csv/");
		File[] listOfFiles = folder.listFiles();

		    for (int i = 0; i < listOfFiles.length; i++) {
		      if (listOfFiles[i].isFile()) {
		        System.out.println(listOfFiles[i].getName());
		      } else if (listOfFiles[i].isDirectory()) {
		        System.out.println("Directory " + listOfFiles[i].getName());
		      }
		    }
	}
	
}
