package nyit.csci.nadir.weka;

import weka.core.Attribute;
import weka.core.Capabilities;
import weka.core.Capabilities.Capability;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.RevisionUtils;
import weka.classifiers.Classifier;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import weka.classifiers.AbstractClassifier;

public class TrainModel
  extends AbstractClassifier {

  /**
   * Returns only the toString() method.
   *
   * @return a string describing the classifier
   */
  public String globalInfo() {
    return toString();
    
  }

  /**
   * Returns the capabilities of this classifier.
   *
   * @return the capabilities
   */
  public Capabilities getCapabilities() {
    weka.core.Capabilities result = new weka.core.Capabilities(this);

    result.enable(weka.core.Capabilities.Capability.NOMINAL_ATTRIBUTES);
    result.enable(weka.core.Capabilities.Capability.NUMERIC_ATTRIBUTES);
    result.enable(weka.core.Capabilities.Capability.DATE_ATTRIBUTES);
    result.enable(weka.core.Capabilities.Capability.MISSING_VALUES);
    result.enable(weka.core.Capabilities.Capability.NOMINAL_CLASS);
    result.enable(weka.core.Capabilities.Capability.MISSING_CLASS_VALUES);


    result.setMinimumNumberInstances(0);

    return result;
  }

  /**
   * only checks the data against its capabilities.
   *
   * @param i the training data
   */
  public void buildClassifier(Instances i) throws Exception {
    // can classifier handle the data?
    getCapabilities().testWithFail(i);
  }

  /**
   * Classifies the given instance.
   *
   * @param i the instance to classify
   * @return the classification result
   */
  public double classifyInstance(Instance i) throws Exception {
	  
	  try(FileWriter fw = new FileWriter("temp/test.rules", true);
			   	BufferedWriter bw = new BufferedWriter(fw);
			    PrintWriter out = new PrintWriter(bw)){
		  
	  //PrintWriter out = new PrintWriter("test.rules");
	  Object[] s = new Object[i.numAttributes()];
    
	  
    for (int j = 0; j < s.length; j++) {
      if (!i.isMissing(j)) {
        if (i.attribute(j).isNominal())
          s[j] = new String(i.stringValue(j));
        else if (i.attribute(j).isNumeric())
          s[j] = new Double(i.value(j));
      }
    }
    
    // set class value to missing
    s[i.classIndex()] = null;
    double p = Output1.classify(s);
   
    //Yash Program for snort rule

	String type_packet = null;
	int no_of_packets = 0;
	//String dest_ip=null;
	//String source_ip=null;
	String tcp_fin="";
	String tcp_syn="";
	String tcp_rst="";
	String tcp_psh="";
	String tcp_ack="";
	String tcp_urg="";
	String tcp_ece="";
	String tcp_cwr="";
	int ether_type_avg;
	int wirelen_avg;
	int ip_offset_avg;
	int ip_length_avg;
	int ip_ver_avg;
	int ip_hlen_avg;
	int ip_flag_avg;
	int ip_type_avg;
	int tcp_offset_avg;
	int tcp_length_avg;
	int tcp_hlen_avg;
	int tcp_reserve_avg;
	int tcp_window_avg = 0;
	int tcp_urgent_avg;
	int payload_offset_avg;
	int payload_length_avg;
	String anomaly_score= null;

	int syn_count = 0;
	int psh_count =0;
	int ack_count=0;
	int rst_count =0;
	int fin_count =0;
	
	
	String msg ="[*]attack-detected";
	String rule ="";
    
    if(p==0){
    	//System.out.println("NORMAL");
    }else if(p==1){
    	msg = "[*]attack-detected";
    	
    	//System.out.print("Probe ");
    	
    for(int j=0; j < s.length;j++){
    	
    	//System.out.print(s[j]);
    	
    	
    	if(s[0].equals("TCP")){
    		type_packet="tcp";
    	}else if(s[0].equals("HTTP")){
    		type_packet="http";
    	}else if(s[0].equals("UDP")){
    		type_packet="udp";
    	}else{
    		type_packet="ip";
    	}
    	
    	if(!s[1].equals("0")){
    		no_of_packets=((Double) s[1]).intValue();
    	}
    	
    	//flags
    	if(!s[2].equals("0")){
    		tcp_fin="F";
    		fin_count = ((Double) s[2]).intValue();
    	}if(!s[3].equals("0")){
    		tcp_syn="S";
    		syn_count = ((Double) s[3]).intValue();
    	}if(!s[4].equals("0")){
    		tcp_rst="R";
    		rst_count = ((Double) s[4]).intValue();
    	}if(!s[5].equals("0")){
    		tcp_psh="P";
    		psh_count = ((Double) s[5]).intValue();
    	}if(!s[6].equals("0")){
    		tcp_ack="A";
    		ack_count = ((Double) s[6]).intValue();
    	}if(!s[7].equals("0")){
    		tcp_urg="U";
    	}if(!s[8].equals("0")){
    		tcp_ece="E";
    	}if(!s[9].equals("0")){
    		tcp_cwr="C";
    	}
    	//
    	if(type_packet=="http"){
    		
    	}
    if(type_packet=="tcp"){
    	if(syn_count==0 & ack_count==no_of_packets){
    		if(no_of_packets==psh_count){
    			rule = "alert "+type_packet+" $EXTERNAL_NET any -> $HOME_NET any (msg: \""+msg+" on "+tcp_psh+tcp_ack+"\"; flags:"+tcp_psh+tcp_ack+"; flow: to_server; threshold: type both, track by_dst, count "+psh_count+", seconds 4;  sid:";
    			//System.out.println(rule);
    			out.println(rule);
    		}else{
    		rule = "alert "+type_packet+" $EXTERNAL_NET any -> $HOME_NET any (msg: \""+msg+" on "+tcp_ack+"\"; flags:"+tcp_ack+"; flow: to_server; threshold: type both, track by_dst, count "+ack_count+", seconds 4; sid:";
    		//System.out.println(rule);
    		out.println(rule);
    		}
    	}
    	else if(syn_count>0 && no_of_packets/syn_count != 1){
    		if(psh_count>0 && ack_count>0 && no_of_packets==syn_count+ack_count){
    			rule = "alert "+type_packet+" $EXTERNAL_NET any -> $HOME_NET any (msg: \""+msg+" on "+tcp_syn+"\"; flags:"+tcp_syn+"; flow: to_server; threshold: type both, track by_dst, count "+syn_count+", seconds 4; sid:";
    			//System.out.println(rule);
    			out.println(rule);
    		}
    	}
    	else if(no_of_packets==rst_count){
    		rule = "alert "+type_packet+" $EXTERNAL_NET any -> $HOME_NET any (msg: \""+msg+" on "+tcp_rst+tcp_ack+"\"; flags:"+tcp_rst+tcp_ack+"; flow: to_server; threshold: type both, track by_dst, count "+rst_count+", seconds 4; sid:";
    		//System.out.println(rule);
    		out.println(rule);
    		}
    	}else if(type_packet=="udp"){
    		if(((Double) s[25]).intValue()==42){
    			rule = "alert "+type_packet+" $EXTERNAL_NET any -> $HOME_NET any (msg: \""+msg+" on "+type_packet+"\"; dsize:>42; sid:";
    			//System.out.println(rule);
    			out.println(rule);
    		}
    	}else{
    		System.out.println(msg+" alert-unknown");
    	}
    
    }
  //  System.out.print("\n");	
    }else if(p==2){
    	msg = "[*]attack-detected";
    	
    	
    	//System.out.print("R2L ");
        for(int j=0; j < s.length;j++){
        	
        	//System.out.print(s[j]+" ");
        	
        	if(s[0].equals("TCP")){
        		type_packet="tcp";
        	}else if(s[0].equals("HTTP")){
        		type_packet="tcp";
        	}else if(s[0].equals("UDP")){
        		type_packet="udp";
        	}else{
        		type_packet="ip";
        	}
        	
        	if(!s[1].equals("0")){
        		no_of_packets=((Double) s[1]).intValue();
        	}
        	
        	if(!s[23].equals("0")){
        		tcp_window_avg=((Double) s[23]).intValue();
        	}
        	//flags
        	if(!s[2].equals("0")){
        		tcp_fin="F";
        		fin_count = ((Double) s[2]).intValue();
        	}if(!s[3].equals("0")){
        		tcp_syn="S";
        		syn_count = ((Double) s[3]).intValue();
        	}if(!s[4].equals("0")){
        		tcp_rst="R";
        		rst_count = ((Double) s[4]).intValue();
        	}if(!s[5].equals("0")){
        		tcp_psh="P";
        		psh_count = ((Double) s[5]).intValue();
        	}if(!s[6].equals("0")){
        		tcp_ack="A";
        		ack_count = ((Double) s[6]).intValue();
        	}if(!s[7].equals("0")){
        		tcp_urg="U";
        	}if(!s[8].equals("0")){
        		tcp_ece="E";
        	}if(!s[9].equals("0")){
        		tcp_cwr="C";
        	}
        	//
        	if(no_of_packets==rst_count+ack_count && psh_count>0){
        			rule = "alert "+type_packet+" $EXTERNAL_NET any -> $HOME_NET any (msg: \""+msg+" on "+tcp_psh+tcp_ack+"\"; flags:"+tcp_psh+tcp_ack+"; window: "+tcp_window_avg+"; flow: to_server; threshold: type both, track by_dst, count "+psh_count+", seconds 4;  sid:";
        			//System.out.println(rule);
        			out.println(rule);	
        		}
        	else{
        		//System.out.println(msg+" alert-unknown");
        	}
        }
        	
       // System.out.print("\n");
    }
    else if(p==3){
    	msg = "[*]attack-detected";
    	
    	//System.out.print("DOS ");
    	
        for(int j=0; j < s.length;j++){
        	
        	//System.out.print(s[j]);
        	
        	
        	
        	if(s[0].equals("TCP")){
        		type_packet="tcp";
        	}else if(s[0].equals("HTTP")){
        		type_packet="tcp";
        	}else if(s[0].equals("UDP")){
        		type_packet="udp";
        	}else{
        		type_packet="ip";
        	}
        	
        	if(!s[1].equals("0")){
        		no_of_packets=((Double) s[1]).intValue();
        	}
        	
        	if(!s[23].equals("0")){
        		tcp_window_avg=((Double) s[23]).intValue();
        	}
        	//flags
        	if(!s[2].equals("0")){
        		tcp_fin="F";
        		fin_count = ((Double) s[2]).intValue();
        	}if(!s[3].equals("0")){
        		tcp_syn="S";
        		syn_count = ((Double) s[3]).intValue();
        	}if(!s[4].equals("0")){
        		tcp_rst="R";
        		rst_count = ((Double) s[4]).intValue();
        	}if(!s[5].equals("0")){
        		tcp_psh="P";
        		psh_count = ((Double) s[5]).intValue();
        	}if(!s[6].equals("0")){
        		tcp_ack="A";
        		ack_count = ((Double) s[6]).intValue();
        	}if(!s[7].equals("0")){
        		tcp_urg="U";
        	}if(!s[8].equals("0")){
        		tcp_ece="E";
        	}if(!s[9].equals("0")){
        		tcp_cwr="C";
        	}
        	//
        	
        	if(no_of_packets==syn_count){
        		rule = "alert "+type_packet+" $EXTERNAL_NET any -> $HOME_NET any (msg: \""+msg+" on "+tcp_syn+"\"; flags:"+tcp_syn+"; flow: stateless; threshold: type both, track by_src, count "+syn_count+", seconds 4; sid:";
    			//System.out.println(rule);
    			out.println(rule);
        	}else{
        		System.out.println(msg+" alert-unknown");
        	}
        	
        }
        	//System.out.print("\n");
        	
    }
    //for unknown attack pattern to research about in near future.....
    else{
    	//unknown value of p
    	System.out.println(msg+" Still in process");
    }
    out.flush();
    out.close();
    return p;
	 }
  }

  /**
   * Returns the revision string.
   * 
   * @return        the revision
   */
  public String getRevision() {
    return RevisionUtils.extract("1.0");
  }

  /**
   * Returns only the classnames and what classifier it is based on.
   *
   * @return a short description
   */
  public String toString() {
    return "Auto-generated classifier wrapper, based on weka.classifiers.trees.J48 (generated with Weka 3.8.1).\n" + this.getClass().getName() + "/Output1";
  }

  /**
   * Runs the classfier from commandline.
   *
   * @param args the commandline arguments
   */
}
class Output1 {

  public static double classify(Object[] i)
    throws Exception {

    double p = Double.NaN;
    p = Output1.N7506e9220(i);
    return p;
  }
  static double N7506e9220(Object []i) {
    double p = Double.NaN;
    if (i[3] == null) {
      p = 0;
    } else if (((Double) i[3]).doubleValue() <= 28.0) {
    p = Output1.N4ee285c61(i);
    } else if (((Double) i[3]).doubleValue() > 28.0) {
    p = Output1.N1edf1c9668(i);
    } 
    return p;
  }
  static double N4ee285c61(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 1392.0) {
    p = Output1.N621be5d12(i);
    } else if (((Double) i[11]).doubleValue() > 1392.0) {
    p = Output1.N1b701da163(i);
    } 
    return p;
  }
  static double N621be5d12(Object []i) {
    double p = Double.NaN;
    if (i[0] == null) {
      p = 0;
    } else if (i[0].equals("UDP")) {
    p = Output1.N573fd7453(i);
    } else if (i[0].equals("TCP")) {
    p = Output1.N5e8c92f412(i);
    } else if (i[0].equals("HTTP")) {
    p = Output1.N6bf2d08e53(i);
    } else if (i[0].equals("OTHER")) {
      p = 0;
    } 
    return p;
  }
  static double N573fd7453(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() <= 64.0) {
    p = Output1.N15327b794(i);
    } else if (((Double) i[11]).doubleValue() > 64.0) {
    p = Output1.N4f2410ac5(i);
    } 
    return p;
  }
  static double N15327b794(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 94.0) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() > 94.0) {
      p = 1;
    } 
    return p;
  }
  static double N4f2410ac5(Object []i) {
    double p = Double.NaN;
    if (i[17] == null) {
      p = 0;
    } else if (((Double) i[17]).doubleValue() <= 1.0) {
    p = Output1.N722c41f46(i);
    } else if (((Double) i[17]).doubleValue() > 1.0) {
    p = Output1.N22927a8110(i);
    } 
    return p;
  }
  static double N722c41f46(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 51.0) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() > 51.0) {
    p = Output1.N5b80350b7(i);
    } 
    return p;
  }
  static double N5b80350b7(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 118.0) {
    p = Output1.N5d6f64b18(i);
    } else if (((Double) i[16]).doubleValue() > 118.0) {
      p = 0;
    } 
    return p;
  }
  static double N5d6f64b18(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 1;
    } else if (((Double) i[16]).doubleValue() <= 62.0) {
      p = 1;
    } else if (((Double) i[16]).doubleValue() > 62.0) {
    p = Output1.N32a1bec09(i);
    } 
    return p;
  }
  static double N32a1bec09(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 81.0) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() > 81.0) {
      p = 1;
    } 
    return p;
  }
  static double N22927a8110(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 97.0) {
    p = Output1.N78e03bb511(i);
    } else if (((Double) i[11]).doubleValue() > 97.0) {
      p = 0;
    } 
    return p;
  }
  static double N78e03bb511(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 94.0) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() > 94.0) {
      p = 2;
    } 
    return p;
  }
  static double N5e8c92f412(Object []i) {
    double p = Double.NaN;
    if (i[3] == null) {
      p = 0;
    } else if (((Double) i[3]).doubleValue() <= 2.0) {
    p = Output1.N61e4705b13(i);
    } else if (((Double) i[3]).doubleValue() > 2.0) {
    p = Output1.N4e51566940(i);
    } 
    return p;
  }
  static double N61e4705b13(Object []i) {
    double p = Double.NaN;
    if (i[21] == null) {
      p = 0;
    } else if (((Double) i[21]).doubleValue() <= 6.0) {
    p = Output1.N5013489414(i);
    } else if (((Double) i[21]).doubleValue() > 6.0) {
    p = Output1.N20fa23c124(i);
    } 
    return p;
  }
  static double N5013489414(Object []i) {
    double p = Double.NaN;
    if (i[20] == null) {
      p = 0;
    } else if (((Double) i[20]).doubleValue() <= 20.0) {
    p = Output1.N2957fcb015(i);
    } else if (((Double) i[20]).doubleValue() > 20.0) {
    p = Output1.N1b4fb99718(i);
    } 
    return p;
  }
  static double N2957fcb015(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 0;
    } else if (((Double) i[23]).doubleValue() <= 0.0) {
    p = Output1.N1376c05c16(i);
    } else if (((Double) i[23]).doubleValue() > 0.0) {
      p = 0;
    } 
    return p;
  }
  static double N1376c05c16(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 57.0) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() > 57.0) {
    p = Output1.N51521cc117(i);
    } 
    return p;
  }
  static double N51521cc117(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 2;
    } else if (((Double) i[16]).doubleValue() <= 94.0) {
      p = 2;
    } else if (((Double) i[16]).doubleValue() > 94.0) {
      p = 1;
    } 
    return p;
  }
  static double N1b4fb99718(Object []i) {
    double p = Double.NaN;
    if (i[25] == null) {
      p = 0;
    } else if (((Double) i[25]).doubleValue() <= 17.0) {
    p = Output1.Ndeb643219(i);
    } else if (((Double) i[25]).doubleValue() > 17.0) {
      p = 0;
    } 
    return p;
  }
  static double Ndeb643219(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 59.0) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() > 59.0) {
    p = Output1.N28ba21f320(i);
    } 
    return p;
  }
  static double N28ba21f320(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 1;
    } else if (((Double) i[23]).doubleValue() <= 5344.0) {
    p = Output1.N694f943121(i);
    } else if (((Double) i[23]).doubleValue() > 5344.0) {
      p = 0;
    } 
    return p;
  }
  static double N694f943121(Object []i) {
    double p = Double.NaN;
    if (i[3] == null) {
      p = 0;
    } else if (((Double) i[3]).doubleValue() <= 0.0) {
      p = 0;
    } else if (((Double) i[3]).doubleValue() > 0.0) {
    p = Output1.Nf2a0b8e22(i);
    } 
    return p;
  }
  static double Nf2a0b8e22(Object []i) {
    double p = Double.NaN;
    if (i[2] == null) {
      p = 0;
    } else if (((Double) i[2]).doubleValue() <= 0.0) {
    p = Output1.N593634ad23(i);
    } else if (((Double) i[2]).doubleValue() > 0.0) {
      p = 1;
    } 
    return p;
  }
  static double N593634ad23(Object []i) {
    double p = Double.NaN;
    if (i[6] == null) {
      p = 1;
    } else if (((Double) i[6]).doubleValue() <= 1.0) {
      p = 1;
    } else if (((Double) i[6]).doubleValue() > 1.0) {
      p = 0;
    } 
    return p;
  }
  static double N20fa23c124(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 61.0) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() > 61.0) {
    p = Output1.N3581c5f325(i);
    } 
    return p;
  }
  static double N3581c5f325(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 89.0) {
    p = Output1.N6aa8ceb626(i);
    } else if (((Double) i[16]).doubleValue() > 89.0) {
      p = 0;
    } 
    return p;
  }
  static double N6aa8ceb626(Object []i) {
    double p = Double.NaN;
    if (i[21] == null) {
      p = 0;
    } else if (((Double) i[21]).doubleValue() <= 8.0) {
    p = Output1.N2530c1227(i);
    } else if (((Double) i[21]).doubleValue() > 8.0) {
      p = 0;
    } 
    return p;
  }
  static double N2530c1227(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 0;
    } else if (((Double) i[23]).doubleValue() <= 221.0) {
      p = 0;
    } else if (((Double) i[23]).doubleValue() > 221.0) {
    p = Output1.N73c6c3b228(i);
    } 
    return p;
  }
  static double N73c6c3b228(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 2;
    } else if (((Double) i[23]).doubleValue() <= 264.0) {
    p = Output1.N48533e6429(i);
    } else if (((Double) i[23]).doubleValue() > 264.0) {
    p = Output1.N7e0b37bc31(i);
    } 
    return p;
  }
  static double N48533e6429(Object []i) {
    double p = Double.NaN;
    if (i[2] == null) {
      p = 2;
    } else if (((Double) i[2]).doubleValue() <= 1.0) {
      p = 2;
    } else if (((Double) i[2]).doubleValue() > 1.0) {
    p = Output1.N64a294a630(i);
    } 
    return p;
  }
  static double N64a294a630(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 2;
    } else if (((Double) i[23]).doubleValue() <= 232.0) {
      p = 2;
    } else if (((Double) i[23]).doubleValue() > 232.0) {
      p = 0;
    } 
    return p;
  }
  static double N7e0b37bc31(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 566.0) {
    p = Output1.N3b95a09c32(i);
    } else if (((Double) i[11]).doubleValue() > 566.0) {
    p = Output1.N4dcbadb439(i);
    } 
    return p;
  }
  static double N3b95a09c32(Object []i) {
    double p = Double.NaN;
    if (i[25] == null) {
      p = 0;
    } else if (((Double) i[25]).doubleValue() <= 34.0) {
    p = Output1.N6ae4099433(i);
    } else if (((Double) i[25]).doubleValue() > 34.0) {
      p = 0;
    } 
    return p;
  }
  static double N6ae4099433(Object []i) {
    double p = Double.NaN;
    if (i[3] == null) {
      p = 2;
    } else if (((Double) i[3]).doubleValue() <= 1.0) {
    p = Output1.N1a93a7ca34(i);
    } else if (((Double) i[3]).doubleValue() > 1.0) {
      p = 0;
    } 
    return p;
  }
  static double N1a93a7ca34(Object []i) {
    double p = Double.NaN;
    if (i[4] == null) {
      p = 2;
    } else if (((Double) i[4]).doubleValue() <= 1.0) {
    p = Output1.N3d82c5f335(i);
    } else if (((Double) i[4]).doubleValue() > 1.0) {
      p = 0;
    } 
    return p;
  }
  static double N3d82c5f335(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 0;
    } else if (((Double) i[23]).doubleValue() <= 277.0) {
      p = 0;
    } else if (((Double) i[23]).doubleValue() > 277.0) {
    p = Output1.N2b05039f36(i);
    } 
    return p;
  }
  static double N2b05039f36(Object []i) {
    double p = Double.NaN;
    if (i[25] == null) {
      p = 2;
    } else if (((Double) i[25]).doubleValue() <= 28.0) {
    p = Output1.N61e717c237(i);
    } else if (((Double) i[25]).doubleValue() > 28.0) {
      p = 2;
    } 
    return p;
  }
  static double N61e717c237(Object []i) {
    double p = Double.NaN;
    if (i[1] == null) {
      p = 0;
    } else if (((Double) i[1]).doubleValue() <= 3.0) {
      p = 0;
    } else if (((Double) i[1]).doubleValue() > 3.0) {
    p = Output1.N66cd51c338(i);
    } 
    return p;
  }
  static double N66cd51c338(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 2;
    } else if (((Double) i[11]).doubleValue() <= 102.0) {
      p = 2;
    } else if (((Double) i[11]).doubleValue() > 102.0) {
      p = 0;
    } 
    return p;
  }
  static double N4dcbadb439(Object []i) {
    double p = Double.NaN;
    if (i[6] == null) {
      p = 3;
    } else if (((Double) i[6]).doubleValue() <= 37.0) {
      p = 3;
    } else if (((Double) i[6]).doubleValue() > 37.0) {
      p = 2;
    } 
    return p;
  }
  static double N4e51566940(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 0;
    } else if (((Double) i[23]).doubleValue() <= 5840.0) {
    p = Output1.N17d1016641(i);
    } else if (((Double) i[23]).doubleValue() > 5840.0) {
    p = Output1.N4cdf35a950(i);
    } 
    return p;
  }
  static double N17d1016641(Object []i) {
    double p = Double.NaN;
    if (i[20] == null) {
      p = 0;
    } else if (((Double) i[20]).doubleValue() <= 24.0) {
    p = Output1.N1b9e191642(i);
    } else if (((Double) i[20]).doubleValue() > 24.0) {
    p = Output1.N759ebb3d47(i);
    } 
    return p;
  }
  static double N1b9e191642(Object []i) {
    double p = Double.NaN;
    if (i[20] == null) {
      p = 0;
    } else if (((Double) i[20]).doubleValue() <= 20.0) {
      p = 0;
    } else if (((Double) i[20]).doubleValue() > 20.0) {
    p = Output1.Nba8a1dc43(i);
    } 
    return p;
  }
  static double Nba8a1dc43(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() <= 138.0) {
    p = Output1.N4f8e5cde44(i);
    } else if (((Double) i[11]).doubleValue() > 138.0) {
      p = 0;
    } 
    return p;
  }
  static double N4f8e5cde44(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 59.0) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() > 59.0) {
    p = Output1.N504bae7845(i);
    } 
    return p;
  }
  static double N504bae7845(Object []i) {
    double p = Double.NaN;
    if (i[20] == null) {
      p = 1;
    } else if (((Double) i[20]).doubleValue() <= 21.0) {
    p = Output1.N3b764bce46(i);
    } else if (((Double) i[20]).doubleValue() > 21.0) {
      p = 1;
    } 
    return p;
  }
  static double N3b764bce46(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 74.0) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() > 74.0) {
      p = 1;
    } 
    return p;
  }
  static double N759ebb3d47(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 545.0) {
    p = Output1.N484b61fc48(i);
    } else if (((Double) i[11]).doubleValue() > 545.0) {
      p = 3;
    } 
    return p;
  }
  static double N484b61fc48(Object []i) {
    double p = Double.NaN;
    if (i[5] == null) {
      p = 0;
    } else if (((Double) i[5]).doubleValue() <= 17.0) {
      p = 0;
    } else if (((Double) i[5]).doubleValue() > 17.0) {
    p = Output1.N45fe3ee349(i);
    } 
    return p;
  }
  static double N45fe3ee349(Object []i) {
    double p = Double.NaN;
    if (i[25] == null) {
      p = 2;
    } else if (((Double) i[25]).doubleValue() <= 38.0) {
      p = 2;
    } else if (((Double) i[25]).doubleValue() > 38.0) {
      p = 0;
    } 
    return p;
  }
  static double N4cdf35a950(Object []i) {
    double p = Double.NaN;
    if (i[25] == null) {
      p = 0;
    } else if (((Double) i[25]).doubleValue() <= 6.0) {
    p = Output1.N4c98385c51(i);
    } else if (((Double) i[25]).doubleValue() > 6.0) {
    p = Output1.N5fcfe4b252(i);
    } 
    return p;
  }
  static double N4c98385c51(Object []i) {
    double p = Double.NaN;
    if (i[17] == null) {
      p = 1;
    } else if (((Double) i[17]).doubleValue() <= 1.0) {
      p = 1;
    } else if (((Double) i[17]).doubleValue() > 1.0) {
      p = 0;
    } 
    return p;
  }
  static double N5fcfe4b252(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 2;
    } else if (((Double) i[16]).doubleValue() <= 94.0) {
      p = 2;
    } else if (((Double) i[16]).doubleValue() > 94.0) {
      p = 0;
    } 
    return p;
  }
  static double N6bf2d08e53(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() <= 313.0) {
    p = Output1.N5eb5c22454(i);
    } else if (((Double) i[11]).doubleValue() > 313.0) {
      p = 0;
    } 
    return p;
  }
  static double N5eb5c22454(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 279.0) {
    p = Output1.N53e25b7655(i);
    } else if (((Double) i[11]).doubleValue() > 279.0) {
      p = 1;
    } 
    return p;
  }
  static double N53e25b7655(Object []i) {
    double p = Double.NaN;
    if (i[1] == null) {
      p = 0;
    } else if (((Double) i[1]).doubleValue() <= 1.0) {
    p = Output1.N73a8dfcc56(i);
    } else if (((Double) i[1]).doubleValue() > 1.0) {
    p = Output1.N3f8f9dd659(i);
    } 
    return p;
  }
  static double N73a8dfcc56(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 231.0) {
    p = Output1.Nea3079757(i);
    } else if (((Double) i[11]).doubleValue() > 231.0) {
      p = 0;
    } 
    return p;
  }
  static double Nea3079757(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() <= 105.0) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() > 105.0) {
    p = Output1.N7e77408558(i);
    } 
    return p;
  }
  static double N7e77408558(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 211.0) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() > 211.0) {
      p = 1;
    } 
    return p;
  }
  static double N3f8f9dd659(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() <= 267.0) {
    p = Output1.Naec635460(i);
    } else if (((Double) i[11]).doubleValue() > 267.0) {
      p = 0;
    } 
    return p;
  }
  static double Naec635460(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 94.0) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() > 94.0) {
    p = Output1.N1c65522161(i);
    } 
    return p;
  }
  static double N1c65522161(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() <= 249.0) {
      p = 1;
    } else if (((Double) i[11]).doubleValue() > 249.0) {
    p = Output1.N58d25a4062(i);
    } 
    return p;
  }
  static double N58d25a4062(Object []i) {
    double p = Double.NaN;
    if (i[11] == null) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() <= 252.0) {
      p = 0;
    } else if (((Double) i[11]).doubleValue() > 252.0) {
      p = 1;
    } 
    return p;
  }
  static double N1b701da163(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() <= 62.0) {
      p = 0;
    } else if (((Double) i[16]).doubleValue() > 62.0) {
    p = Output1.N726f3b5864(i);
    } 
    return p;
  }
  static double N726f3b5864(Object []i) {
    double p = Double.NaN;
    if (i[20] == null) {
      p = 0;
    } else if (((Double) i[20]).doubleValue() <= 26.0) {
      p = 0;
    } else if (((Double) i[20]).doubleValue() > 26.0) {
    p = Output1.N442d9b6e65(i);
    } 
    return p;
  }
  static double N442d9b6e65(Object []i) {
    double p = Double.NaN;
    if (i[1] == null) {
      p = 2;
    } else if (((Double) i[1]).doubleValue() <= 2.0) {
    p = Output1.Nee7d9f166(i);
    } else if (((Double) i[1]).doubleValue() > 2.0) {
      p = 3;
    } 
    return p;
  }
  static double Nee7d9f166(Object []i) {
    double p = Double.NaN;
    if (i[5] == null) {
      p = 2;
    } else if (((Double) i[5]).doubleValue() <= 0.0) {
    p = Output1.N1561509967(i);
    } else if (((Double) i[5]).doubleValue() > 0.0) {
      p = 2;
    } 
    return p;
  }
  static double N1561509967(Object []i) {
    double p = Double.NaN;
    if (i[23] == null) {
      p = 3;
    } else if (((Double) i[23]).doubleValue() <= 232.0) {
      p = 3;
    } else if (((Double) i[23]).doubleValue() > 232.0) {
      p = 2;
    } 
    return p;
  }
  static double N1edf1c9668(Object []i) {
    double p = Double.NaN;
    if (i[17] == null) {
      p = 1;
    } else if (((Double) i[17]).doubleValue() <= 1.0) {
    p = Output1.N368102c869(i);
    } else if (((Double) i[17]).doubleValue() > 1.0) {
    p = Output1.N1963006a71(i);
    } 
    return p;
  }
  static double N368102c869(Object []i) {
    double p = Double.NaN;
    if (i[16] == null) {
      p = 1;
    } else if (((Double) i[16]).doubleValue() <= 63.0) {
      p = 1;
    } else if (((Double) i[16]).doubleValue() > 63.0) {
    p = Output1.N6996db870(i);
    } 
    return p;
  }
  static double N6996db870(Object []i) {
    double p = Double.NaN;
    if (i[20] == null) {
      p = 3;
    } else if (((Double) i[20]).doubleValue() <= 21.0) {
      p = 3;
    } else if (((Double) i[20]).doubleValue() > 21.0) {
      p = 1;
    } 
    return p;
  }
  static double N1963006a71(Object []i) {
    double p = Double.NaN;
    if (i[25] == null) {
      p = 0;
    } else if (((Double) i[25]).doubleValue() <= 31.0) {
    p = Output1.N7fbe847c72(i);
    } else if (((Double) i[25]).doubleValue() > 31.0) {
      p = 3;
    } 
    return p;
  }
  static double N7fbe847c72(Object []i) {
    double p = Double.NaN;
    if (i[20] == null) {
      p = 0;
    } else if (((Double) i[20]).doubleValue() <= 22.0) {
    p = Output1.N41975e0173(i);
    } else if (((Double) i[20]).doubleValue() > 22.0) {
      p = 0;
    } 
    return p;
  }
  static double N41975e0173(Object []i) {
    double p = Double.NaN;
    if (i[4] == null) {
      p = 1;
    } else if (((Double) i[4]).doubleValue() <= 24.0) {
      p = 1;
    } else if (((Double) i[4]).doubleValue() > 24.0) {
      p = 0;
    } 
    return p;
  }
}

