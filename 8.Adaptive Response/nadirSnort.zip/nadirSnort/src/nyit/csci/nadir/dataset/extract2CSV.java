package nyit.csci.nadir.dataset;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class extract2CSV {
	public static int sum=0;
	public static int count=0;
	public static int numFiles = 0;
	//this function converts the boolean values to 0s and 1s
	public static String getValue(String a){
		if(a.equals("TRUE") || a.equals("true")){
			return "1";
		}else{
			return "0";
		}
	}
	
	//Parses the CSV files and writes the summary to the output csv file
	public static void parser(String name,ArrayList<String> inputFiles, String outputPath) throws IOException{

		String inputFile="";
		int filenum = 1;
		
		System.out.println("[*]Still Processing...........");
		
		for(int c=0 ; c<inputFiles.size(); c++){
			
			
			
			inputFile = inputFiles.get(c);
			
			String outputFile= outputPath+filenum+"extracted_"+name+".csv";		
			
			ArrayList<ArrayList<String>> records = new ArrayList<ArrayList<String>>();
			FileReader fr = new FileReader(inputFile);
			BufferedReader br = new BufferedReader(fr);
			String type="";
			String line="";
			int flag=0;
			
			while((line=br.readLine())!=null){
				flag=0;
				ArrayList<String> a = new ArrayList<String>();
				String[] temp=line.split(",",-1);
				//System.out.println(line);
				for(int i=0;i<temp.length;i++){
					//System.out.println(temp[i]);
					if(temp[i].equals("") ){
						a.add("0");
					}else if(temp[i].equalsIgnoreCase("null")){
						a.add("0");
					}
					else{
						a.add(temp[i]);
					}
					
				}
				
				//System.out.println(a);
				if(a.get(0).equalsIgnoreCase("TCP")){
					type="TCP";
				}else if(a.get(0).equalsIgnoreCase("UDP")){
					type="UDP";
				}else if(a.get(0).equalsIgnoreCase("HTTP")){
					type="HTTP";
				}else{
					type="Other";
				}
				if(records.isEmpty()){
					ArrayList<String> firstRow = new ArrayList<String>();
					firstRow.add(type);					//type					0
					firstRow.add(a.get(2));				//timestamp				1
					firstRow.add("1");					//number of frames		2
					firstRow.add(a.get(16));			//dest ip 				3
					firstRow.add(a.get(17));			//source ip				4
					firstRow.add(a.get(6));				//ether dest			5
					firstRow.add(a.get(7));				//ether source			6
					firstRow.add(a.get(20));			//dest port				7
					firstRow.add(a.get(21));			//source port   26-33	8
					firstRow.add(getValue(a.get(26))); 	//tcp fin				9
					firstRow.add(getValue(a.get(27)));	//tcp syn				10
					firstRow.add(getValue(a.get(28)));	//tcp rst				11
					firstRow.add(getValue(a.get(29)));	//tcp psh				12
					firstRow.add(getValue(a.get(30)));	//tcp ack				13
					firstRow.add(getValue(a.get(31)));	//tcp urg				14
					firstRow.add(getValue(a.get(32)));	//tcp ece				15
					firstRow.add(getValue(a.get(33)));	//tcp cwr				16
					firstRow.add(a.get(8));				//eth type sum			17
					firstRow.add("1");					//eth type count``		18	
					firstRow.add(a.get(8)); 			//eth type				19
					firstRow.add(a.get(3));				//wirelen sum			20
					firstRow.add("1");					//wirelen count			21
					firstRow.add(a.get(3));				//wirelen 				22
					firstRow.add(a.get(9));				//ip offset sum			23
					firstRow.add("1");					//ip offset count		24
					firstRow.add(a.get(9));				//ip offset 			25
					firstRow.add(a.get(10));			//ip length sum			26
					firstRow.add("1");					//ip length count		27
					firstRow.add(a.get(10));			//ip length				28
					firstRow.add(a.get(11));			//ip ver sum			29
					firstRow.add("1");					//ip ver count			30
					firstRow.add(a.get(11));			//ip ver				31
					firstRow.add(a.get(12));			//ip hlen sum			32
					firstRow.add("1");					//ip hlen count			33
					firstRow.add(a.get(12));			//ip hlen				34
					firstRow.add(a.get(13));			//ip flag sum			35
					firstRow.add("1");					//ip flag count			36
					firstRow.add(a.get(13));			//ip flag				37
					firstRow.add(a.get(14));			//ip type sum			38
					firstRow.add("1");					//ip type count			39
					firstRow.add(a.get(14));			//ip type				40
					firstRow.add(a.get(18));			//tcp offset sum		41
					firstRow.add("1");					//tcp offset count		42
					firstRow.add(a.get(18));			//tcp offset			43
					firstRow.add(a.get(19));			//tcp length sum		44
					firstRow.add("1");					//tcp length count		45
					firstRow.add(a.get(19));			//tcp length			46
					firstRow.add(a.get(24));			//tcp hlen sum			47
					firstRow.add("1");					//tcp hlen count		48
					firstRow.add(a.get(24));			//tcp hlen				49
					firstRow.add(a.get(25));			//tcp reserve sum		50
					firstRow.add("1");					//tcp reserve count		51
					firstRow.add(a.get(25));			//tcp reserve			52
					firstRow.add(a.get(34));			//tcp window sum		53
					firstRow.add("1");					//tcp window count		54
					firstRow.add(a.get(34));			//tcp window			55
					firstRow.add(a.get(36));			//tcp urgent sum		56
					firstRow.add("1");					//tcp urgent count		57
					firstRow.add(a.get(36));			//tcp urgent			58
					firstRow.add(a.get(54));			//payload_o sum			59
					firstRow.add("1");					//payload_o count		60
					firstRow.add(a.get(54));			//payload_o				61
					firstRow.add(a.get(55));			//payload length sum	62
					firstRow.add("1");					//payload length count	63
					firstRow.add(a.get(55));			//payload length		64
					firstRow.add("?");					//anomaly_score			65
					
					records.add(firstRow);										
				}else{
					for(int i=0;i<records.size();i++){
						String source = a.get(16);
						String src = records.get(i).get(3);
						if(a.get(0).equalsIgnoreCase(records.get(i).get(0))
								&& a.get(16).equals(records.get(i).get(3)) && a.get(17).equals(records.get(i).get(4))
							/*	&& a.get(6).equals(records.get(i).get(5)) && a.get(7).equals(records.get(i).get(6))
								&& a.get(20).equals(records.get(i).get(7)) && a.get(21).equals(records.get(i).get(8))*/){
							flag=1;
							records.get(i).set(2,(Integer.parseInt(records.get(i).get(2))+1)+"");
							records.get(i).set(9,(Integer.parseInt(records.get(i).get(9))+Integer.parseInt(getValue(a.get(26))))+"");
							records.get(i).set(10,(Integer.parseInt(records.get(i).get(10))+Integer.parseInt(getValue(a.get(27))))+"");
							records.get(i).set(11,(Integer.parseInt(records.get(i).get(11))+Integer.parseInt(getValue(a.get(28))))+"");
							records.get(i).set(12,(Integer.parseInt(records.get(i).get(12))+Integer.parseInt(getValue(a.get(29))))+"");
							records.get(i).set(13,(Integer.parseInt(records.get(i).get(13))+Integer.parseInt(getValue(a.get(30))))+"");
							records.get(i).set(14,(Integer.parseInt(records.get(i).get(14))+Integer.parseInt(getValue(a.get(31))))+"");
							records.get(i).set(15,(Integer.parseInt(records.get(i).get(15))+Integer.parseInt(getValue(a.get(32))))+"");
							records.get(i).set(16,(Integer.parseInt(records.get(i).get(16))+Integer.parseInt(getValue(a.get(33))))+"");
							
							records.get(i).set(17,(Integer.parseInt(records.get(i).get(17))+Integer.parseInt(a.get(8)))+"");
							records.get(i).set(18,(Integer.parseInt(records.get(i).get(18))+1)+"");
							records.get(i).set(19, (Integer.parseInt(records.get(i).get(17))/Integer.parseInt(records.get(i).get(18)))+"");
							
							records.get(i).set(20,(Integer.parseInt(records.get(i).get(20))+Integer.parseInt(a.get(3)))+"");
							records.get(i).set(21,(Integer.parseInt(records.get(i).get(21))+1)+"");
							records.get(i).set(22, (Integer.parseInt(records.get(i).get(20))/Integer.parseInt(records.get(i).get(21)))+"");
							
							records.get(i).set(23,(Integer.parseInt(records.get(i).get(23))+Integer.parseInt(a.get(9)))+"");
							records.get(i).set(24,(Integer.parseInt(records.get(i).get(24))+1)+"");
							records.get(i).set(25, (Integer.parseInt(records.get(i).get(23))/Integer.parseInt(records.get(i).get(24)))+"");
							
							records.get(i).set(26,(Integer.parseInt(records.get(i).get(26))+Integer.parseInt(a.get(10)))+"");
							records.get(i).set(27,(Integer.parseInt(records.get(i).get(27))+1)+"");
							records.get(i).set(28, (Integer.parseInt(records.get(i).get(26))/Integer.parseInt(records.get(i).get(27)))+"");
							
							records.get(i).set(29,(Integer.parseInt(records.get(i).get(29))+Integer.parseInt(a.get(11)))+"");
							records.get(i).set(30,(Integer.parseInt(records.get(i).get(30))+1)+"");
							records.get(i).set(31, (Integer.parseInt(records.get(i).get(29))/Integer.parseInt(records.get(i).get(30)))+"");
							
							records.get(i).set(32,(Integer.parseInt(records.get(i).get(32))+Integer.parseInt(a.get(12)))+"");
							records.get(i).set(33,(Integer.parseInt(records.get(i).get(33))+1)+"");
							records.get(i).set(34, (Integer.parseInt(records.get(i).get(32))/Integer.parseInt(records.get(i).get(33)))+"");
							
							records.get(i).set(35,(Integer.parseInt(records.get(i).get(35))+Integer.parseInt(a.get(13)))+"");
							records.get(i).set(36,(Integer.parseInt(records.get(i).get(36))+1)+"");
							records.get(i).set(37, (Integer.parseInt(records.get(i).get(35))/Integer.parseInt(records.get(i).get(36)))+"");
							
							records.get(i).set(38,(Integer.parseInt(records.get(i).get(38))+Integer.parseInt(a.get(14)))+"");
							records.get(i).set(39,(Integer.parseInt(records.get(i).get(39))+1)+"");
							records.get(i).set(40, (Integer.parseInt(records.get(i).get(38))/Integer.parseInt(records.get(i).get(39)))+"");
							
							records.get(i).set(41,(Integer.parseInt(records.get(i).get(41))+Integer.parseInt(a.get(18)))+"");
							records.get(i).set(42,(Integer.parseInt(records.get(i).get(42))+1)+"");
							records.get(i).set(43, (Integer.parseInt(records.get(i).get(41))/Integer.parseInt(records.get(i).get(42)))+"");
							
							records.get(i).set(44,(Integer.parseInt(records.get(i).get(44))+Integer.parseInt(a.get(19)))+"");
							records.get(i).set(45,(Integer.parseInt(records.get(i).get(45))+1)+"");
							records.get(i).set(46, (Integer.parseInt(records.get(i).get(44))/Integer.parseInt(records.get(i).get(45)))+"");
							
							records.get(i).set(47,(Integer.parseInt(records.get(i).get(47))+Integer.parseInt(a.get(24)))+"");
							records.get(i).set(48,(Integer.parseInt(records.get(i).get(48))+1)+"");
							records.get(i).set(49, (Integer.parseInt(records.get(i).get(47))/Integer.parseInt(records.get(i).get(48)))+"");
							
							records.get(i).set(50,(Integer.parseInt(records.get(i).get(50))+Integer.parseInt(a.get(25)))+"");
							records.get(i).set(51,(Integer.parseInt(records.get(i).get(51))+1)+"");
							records.get(i).set(52, (Integer.parseInt(records.get(i).get(50))/Integer.parseInt(records.get(i).get(51)))+"");
							
							records.get(i).set(53,(Integer.parseInt(records.get(i).get(53))+Integer.parseInt(a.get(34)))+"");
							records.get(i).set(54,(Integer.parseInt(records.get(i).get(54))+1)+"");
							records.get(i).set(55, (Integer.parseInt(records.get(i).get(53))/Integer.parseInt(records.get(i).get(54)))+"");
							
							records.get(i).set(56,(Integer.parseInt(records.get(i).get(56))+Integer.parseInt(a.get(36)))+"");
							records.get(i).set(57,(Integer.parseInt(records.get(i).get(57))+1)+"");
							records.get(i).set(58, (Integer.parseInt(records.get(i).get(56))/Integer.parseInt(records.get(i).get(57)))+"");
							
							records.get(i).set(59,(Integer.parseInt(records.get(i).get(59))+Integer.parseInt(a.get(54)))+"");
							records.get(i).set(60,(Integer.parseInt(records.get(i).get(60))+1)+"");
							records.get(i).set(61, (Integer.parseInt(records.get(i).get(59))/Integer.parseInt(records.get(i).get(60)))+"");
							
							records.get(i).set(62,(Integer.parseInt(records.get(i).get(59))+Integer.parseInt(a.get(55)))+"");
							records.get(i).set(63,(Integer.parseInt(records.get(i).get(63))+1)+"");
							records.get(i).set(64, (Integer.parseInt(records.get(i).get(62))/Integer.parseInt(records.get(i).get(63)))+"");
							records.get(i).set(65,(records.get(i).get(65))+"");
					
						}else{
							continue;
						}
					}
					if(flag==0){
						ArrayList<String> firstRow = new ArrayList<String>();
						firstRow.add(type);
						firstRow.add(a.get(2));
						firstRow.add("1");
						firstRow.add(a.get(16));
						firstRow.add(a.get(17));
						firstRow.add(a.get(6));
						firstRow.add(a.get(7));
						firstRow.add(a.get(20));
						firstRow.add(a.get(21));
						firstRow.add(getValue(a.get(26))); 	//tcp fin
						firstRow.add(getValue(a.get(27)));	//tcp syn
						firstRow.add(getValue(a.get(28)));	//tcp rst
						firstRow.add(getValue(a.get(29)));	//tcp psh
						firstRow.add(getValue(a.get(30)));	//tcp ack
						firstRow.add(getValue(a.get(31)));	//tcp urg
						firstRow.add(getValue(a.get(32)));	//tcp ece
						firstRow.add(getValue(a.get(33)));	//tcp cwr
						firstRow.add(a.get(8));				//eth type sum			17
						firstRow.add("1");					//eth type count``		18	
						firstRow.add(a.get(8)); 			//eth type				19
						firstRow.add(a.get(3));				//wirelen sum			20
						firstRow.add("1");					//wirelen count			21
						firstRow.add(a.get(3));				//wirelen 				22
						firstRow.add(a.get(9));				//ip offset sum			23
						firstRow.add("1");					//ip offset count		24
						firstRow.add(a.get(9));				//ip offset 			25
						firstRow.add(a.get(10));			//ip length sum			26
						firstRow.add("1");					//ip length count		27
						firstRow.add(a.get(10));			//ip length				28
						firstRow.add(a.get(11));			//ip ver sum			29
						firstRow.add("1");					//ip ver count			30
						firstRow.add(a.get(11));			//ip ver				31
						firstRow.add(a.get(12));			//ip hlen sum			32
						firstRow.add("1");					//ip hlen count			33
						firstRow.add(a.get(12));			//ip hlen				34
						firstRow.add(a.get(13));			//ip flag sum			35
						firstRow.add("1");					//ip flag count			36
						firstRow.add(a.get(13));			//ip flag				37
						firstRow.add(a.get(14));			//ip type sum			38
						firstRow.add("1");					//ip type count			39
						firstRow.add(a.get(14));			//ip type				40
						firstRow.add(a.get(18));			//tcp offset sum		41
						firstRow.add("1");					//tcp offset count		42
						firstRow.add(a.get(18));			//tcp offset			43
						firstRow.add(a.get(19));			//tcp length sum		44
						firstRow.add("1");					//tcp length count		45
						firstRow.add(a.get(19));			//tcp length			46
						firstRow.add(a.get(24));			//tcp hlen sum			47
						firstRow.add("1");					//tcp hlen count		48
						firstRow.add(a.get(24));			//tcp hlen				49
						firstRow.add(a.get(25));			//tcp reserve sum		50
						firstRow.add("1");					//tcp reserve count		51
						firstRow.add(a.get(25));			//tcp reserve			52
						firstRow.add(a.get(34));			//tcp window sum		53
						firstRow.add("1");					//tcp window count		54
						firstRow.add(a.get(34));			//tcp window			55
						firstRow.add(a.get(36));			//tcp urgent sum		56
						firstRow.add("1");					//tcp urgent count		57
						firstRow.add(a.get(36));			//tcp urgent			58
						firstRow.add(a.get(54));			//payload_o sum			59
						firstRow.add("1");					//payload_o count		60
						firstRow.add(a.get(54));			//payload_o				61
						firstRow.add(a.get(55));			//payload_o sum			62
						firstRow.add("1");					//payload_o count		63
						firstRow.add(a.get(55));			//payload_o				64
						firstRow.add("?");					//anomaly score			65
						
						records.add(firstRow);
					}
				}
			}
			
			ArrayList<ArrayList<String>> refactoredRecords  = new ArrayList<ArrayList<String>>();
			for(int i=0;i<records.size();i++){
				ArrayList<String> currentRow = new ArrayList<String>();
				currentRow = records.get(i);
				ArrayList<String> editedRow = new ArrayList<String>();
				for(int j=0;j<currentRow.size();j++){
					
					if(j==5 || j==6 || j==7 || j==8 || j==17 || j==18 || j==20 || j==21 || j==23 || j==24 || j==26 || j==27 || j==29 || j==30
						|| j==32 || j==33 || j==35 || j==36 || j==38 || j==39 || j==41 || j==42 || j==44 || j==45
						|| j==47 || j==48 || j==50 || j==51 || j==53 || j==54 || j==56 || j==57 || j==59 || j==60
						|| j==62 || j==63){
						
						continue;
					}else{
						editedRow.add(currentRow.get(j));
					}
				}
				refactoredRecords.add(editedRow);
			}
			//System.out.println(refactoredRecords);
			FileWriter writer = new FileWriter(outputFile);
			
			
			//writer.write("TYPE_PACKET,FIRST_TIMESTAMP,NO_OF_PACKETS,DEST_IP,SOURCE_IP,DEST_ETHER,SOURCE_ETHER,DEST_PORT,SOURCE_PORT,TCP_FIN,TCP_SYN,TCP_RST,TCP_PSH,TCP_ACK,TCP_URG,TCP_ECE,TCP_CWR,ETHER_TYPE_SUM,ETHER_TYPE_COUNT,ETHER_TYPE_AVG,WIRELEN_SUM,WIRELEN_COUNT,WIRELEN_AVG,IP_OFFSET_SUM,IP_OFFSET_COUNT,IP_OFFSET_AVG,IP_LENGTH_SUM,IP_LENGTH_COUNT,IP_LENGTH_AVG,IP_VER_SUM,IP_VER_COUNT,IP_VER_AVG,IP_HLEN_SUM,IP_HLEN_COUNT,IP_HLEN_AVG,IP_FLAG_SUM,IP_FLAG_COUNT,IP_FLAG_AVG,IP_TYPE_SUM,IP_TYPE_COUNT,IP_TYPE_AVG,TCP_OFFSET_SUM,TCP_OFFSET_COUNT,TCP_OFFSET_AVG,TCP_LENGTH_SUM,TCP_LENGTH_COUNT,TCP_LENGTH_AVG,TCP_HLEN_SUM,TCP_HLEN_COUNT,TCP_HLEN_AVG,TCP_RESERVE_SUM,TCP_RESERVE_COUNT,TCP_RESERVE_AVG,TCP_WINDOW_SUM,TCP_WINDOW_COUNT,TCP_WINDOW_AVG,TCP_URGENT_SUM,TCP_URGENT_COUNT,TCP_URGENT_AVG,PAYLOAD_OFFSET_SUM,PAYLOAD_OFFSET_COUNT,PAYLOAD_OFFSET_AVG,PAYLOAD_LENGTH_SUM,PAYLOAD_LENGTH_COUNT,PAYLOAD_LENGTH_AVG,ANOMALY_SCORE");
			writer.write("TYPE_PACKET,FIRST_TIMESTAMP,NO_OF_PACKETS,DEST_IP,SOURCE_IP,TCP_FIN,TCP_SYN,TCP_RST,TCP_PSH,TCP_ACK,TCP_URG,TCP_ECE,TCP_CWR,ETHER_TYPE_AVG,WIRELEN_AVG,IP_OFFSET_AVG,IP_LENGTH_AVG,IP_VER_AVG,IP_HLEN_AVG,IP_FLAG_AVG,IP_TYPE_AVG,TCP_OFFSET_AVG,TCP_LENGTH_AVG,TCP_HLEN_AVG,TCP_RESERVE_AVG,TCP_WINDOW_AVG,TCP_URGENT_AVG,PAYLOAD_OFFSET_AVG,PAYLOAD_LENGTH_AVG,ANOMALY_SCORE");
		    writer.append('\n');
			
			
			for(int f=0;f<refactoredRecords.size();f++){
				ArrayList<String> test = refactoredRecords.get(f);
				
				String collect = test.stream().collect(Collectors.joining(","));
				writer.append(collect);
			    writer.append('\n');
			    
			}
			writer.close();
			filenum++;
			br.close();
			fr.close();
			
		}
		numFiles = filenum-1;
		//System.out.println("Total "+ numFiles +" files Extracted !");
		//System.out.println("Done :)");
		
	}
	
	public static ArrayList<String> splitFiles(String name,String fileName, String outputPath, long millisecondsRange) throws IOException{
        String fileRead="";
        int fileCounter=1;
        ArrayList<String> files = new ArrayList<String>();
        String csvFile = outputPath+fileCounter+"splited_"+name+".csv";
        files.add(csvFile);
        FileWriter cwriter = new FileWriter(csvFile);
        long temp=0;
        try {
        	FileReader f = new FileReader(fileName);
            BufferedReader br = new BufferedReader(f );
            String[] result=null;
            int i=0;
            System.out.println("[*]Processing...........");
            while((fileRead = br.readLine()) != null) {
            	result = fileRead.split(",",-1);       
            	if(i==0){
            		//-------change the value here---------
            		temp = Long.parseLong(result[2])+millisecondsRange;            		
            	}
            	if(Long.parseLong(result[2])<=temp){           		
            		CSVUtils.writeLine(cwriter, Arrays.asList(result));
            	}else{
            		//-------change the value here----------
            		temp = Long.parseLong(result[2])+millisecondsRange;
            		cwriter.flush();
            	    cwriter.close();
            		csvFile = outputPath+(++fileCounter)+"splited_"+name+".csv";
            		files.add(csvFile);
            		cwriter = new FileWriter(csvFile);
            		CSVUtils.writeLine(cwriter, Arrays.asList(result));
            	}
            	i++;
            }
            br.close();
            f.close();
        }

        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        cwriter.flush();
	    cwriter.close();
	    
	    return files;
	}
	
			
	public static void extract2csv(String csv_name,String input_raw,String extract_path,String split_path,String arff_path,String final_extract,long milisec) throws Exception{
		
		String name = csv_name;
		
		//--------Enter the input path here---------
		String inputPath = input_raw;
		String inputFile = inputPath+name+".csv";
		//--------Enter the final summary output path here--------
		String OutputPath = extract_path;
		//--------Enter the final output path for arff file here----
		String finalArffPath = arff_path;
		//--------Enter the split file output path here----------
		String splitOutputPath = split_path;
		long millisecondsRange = milisec; 
		String final_extracted =final_extract;
		//10000milisec = 10 sec
		
		String fname = name+"_"+millisecondsRange;
		//Call the splitFiles function and returns the names of split files in the form of an array list
		ArrayList<String> files = splitFiles(fname,inputFile, splitOutputPath, millisecondsRange);
		//takes the split files as argument and writes the summary on a csv file
		parser(fname,files,OutputPath);
		merge2CSV mergecsv = new merge2CSV();
		mergecsv.merge(name, final_extracted, OutputPath, millisecondsRange, numFiles);
		csv2Arff arff = new csv2Arff();
		//Final_Extracted_nmap_machine.pcap_4000.csv
		//arff.Convert(final_extracted+"Final_Extracted_"+name+"_"+millisecondsRange+".csv", finalArffPath+"Final_Extracted_"+name+"_"+millisecondsRange+".csv.arff");
        System.out.println("[*]Done.......");
                     
	}

}
