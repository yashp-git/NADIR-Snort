package nyit.csci.nadir.snort;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class snortService {

		public static void reloadSnort() throws IOException, InterruptedException{
			
			snortService snort = new snortService();
			
//			
//			String out = snort.executeCommand("sudo service apache2 restart");
//			System.out.println(out);
			System.out.println("[*] Snort Service");
//Service snort restart

			snort.executeCommand("sudo ip link set br2 up");
			System.out.println("[*] br2 UP");
			snort.executeCommand("sudo service snort2 start");
			System.out.println("[*] SNORT-2 START");
			Thread.sleep(15000);
			System.out.println("[*] SNORT-2 STARTED");
			System.out.println("[*] SNORT-1 STOP");
			snort.executeCommand("sudo service snort1 stop");
			System.out.println("[*] br1 DOWN");
			snort.executeCommand("sudo ip link set br1 down");
			snort.executeCommand("sudo ip link set br1 up");
			System.out.println("[*] br1 UP");
			snort.executeCommand("sudo service snort1 restart");
			System.out.println("[*] SNORT-1 START");
			Thread.sleep(15000);
			System.out.println("[*] SNORT-1 STARTED");
			snort.executeCommand("sudo service snort2 stop");
			System.out.println("[*] SNORT-2 STOPED");
			snort.executeCommand("sudo ip link set br2 down");
			System.out.println("[*] br2 DOWN");
			System.out.println("[*] DONE");
			
	}

		private String executeCommand(String command) {
			StringBuffer output = new StringBuffer();

			Process p;
			try {
				p = Runtime.getRuntime().exec(command);
				p.waitFor();
				BufferedReader reader =
	                            new BufferedReader(new InputStreamReader(p.getInputStream()));

	                        String line = "";
				while ((line = reader.readLine())!= null) {
					output.append(line + "\n");
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

			return output.toString();

		}
				
}
