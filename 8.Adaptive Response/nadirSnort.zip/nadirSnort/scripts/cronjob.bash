#!/bin/bash
java /home/victim/workspace/nadirSnort/bin/nyit/csci/nadir/snort/Main
