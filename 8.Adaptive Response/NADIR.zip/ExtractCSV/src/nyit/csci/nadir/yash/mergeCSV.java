package nyit.csci.nadir.yash;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
import org.apache.commons.io.FileUtils;

public class mergeCSV {
	static String path1="D:\\Extract_csv\\zsplit";
    static String path2="D:\\Extract_csv\\zextracted";
    static File file1 = new File(path1);
    static File file2 = new File(path2);
    

    public static void merge(String name,long millisecondsRange,int numFiles) {

        
        String idFile = name+"_"+millisecondsRange;
        
        File[] files1 = file1.listFiles();
        File[] files2 = file2.listFiles();
        
        
        try {
            mergeCsvFiles(idFile, numFiles);
            //System.out.println("All CSV files Merged !! :/");
            
            System.out.println("[*]Merging "+numFiles+ " Files......");
            
            FileUtils.cleanDirectory(new File(path1));
            FileUtils.cleanDirectory(new File(path2));
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        //System.out.println("All Temporary CSV files Deleted !! :/");
        System.out.println("[*]Deleting "+numFiles+ " Files......");
        
    }
    

    private static void mergeCsvFiles(String idFile, int numFiles) throws IOException {

        // Variables
        ArrayList<File> files = new ArrayList<File>();
        Iterator<File> iterFiles;
        File fileOutput;
        BufferedWriter fileWriter;
        BufferedReader fileReader;
        String csvFile;
        String csvFinal = "D:\\Extract_csv\\final_extracted_csv\\" + "Final_Extracted_"+idFile + ".csv";
        String[] headers = null;
        String header = null;

        // Files: Input
        for (int i = 1; i <= numFiles; i++) {
            csvFile = "D:\\Extract_csv\\zextracted\\" + i + "extracted_"+ idFile +".csv";
            files.add(new File(csvFile));
        }

        // Files: Output
        fileOutput = new File(csvFinal);
        if (fileOutput.exists()) {
            fileOutput.delete();
        }
        try {
            fileOutput.createNewFile();
            // log
            // System.out.println("Output: " + fileOutput);
        } catch (IOException e) {
            // log
        }

        iterFiles = files.iterator();
        fileWriter = new BufferedWriter(new FileWriter(csvFinal, true));

        // Headers
        Scanner scanner = new Scanner(files.get(0));
        if (scanner.hasNextLine())
            header = scanner.nextLine();
        // if (scanner.hasNextLine()) headers = scanner.nextLine().split(";");
        scanner.close();

        /*
         * System.out.println(header); for(String s: headers){
         * fileWriter.write(s); System.out.println(s); }
         */

        fileWriter.write(header);
        fileWriter.newLine();

        while (iterFiles.hasNext()) {

            String line;// = null;
            String[] firstLine;// = null;

            File nextFile = iterFiles.next();
            fileReader = new BufferedReader(new FileReader(nextFile));

            if ((line = fileReader.readLine()) != null)
                firstLine = line.split(";");

            while ((line = fileReader.readLine()) != null) {
                fileWriter.write(line);
                fileWriter.newLine();
            }
            fileReader.close();
        }

        fileWriter.close();

    }

}