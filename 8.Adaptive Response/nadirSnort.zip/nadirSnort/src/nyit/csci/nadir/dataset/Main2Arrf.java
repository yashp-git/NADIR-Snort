package nyit.csci.nadir.dataset;

public class Main2Arrf {

	public static void main(String[] args) throws Exception {
		
		int millisecondsRange=4000;
		String name="merged_nmap_dos_ddos_R2L_train_dataset.csv";
		String final_extract ="Extract_csv/final/";
		String arff_path="Extract_csv/final_extracted_arff/";
		//Final_Extracted_nmap_machine.pcap_4000.csv
		csv2Arff arff = new csv2Arff();
		arff.Convert(final_extract+"Final_Extracted_"+name+"_"+millisecondsRange+".csv", arff_path+"Final_Extracted_"+name+"_"+millisecondsRange+".csv.arff");
		//arff.Convert(final_extract+name, arff_path+"Final_Extracted_"+name+"_"+millisecondsRange+".csv.arff");
		System.out.println("[*]Done.......");

	}

}
