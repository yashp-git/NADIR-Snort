package nyit.csci.nadir.patel;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class parseWeka {

	public static void main(String[] args) throws IOException {
	
		WekaWrapper wekarun = new WekaWrapper();
		//String[] java_arg = new String[] {"-t \"D:\\Final_Extracted_portscanfrom164on252.pcap_40001.csv.arff\"", "-T \"D:\\Final_Extracted_portscanfrom164on252.pcap_40001_copy.csv.arff\""};
		
			wekarun.runClassifier(new WekaWrapper(), args);
		    
		    trimfile("test.rules");
		    System.out.println("[*]Done");
		    
		    
	}
	
	public static void trimfile(String filename) throws IOException{
		
		System.out.println("[*]Generating Snort Rules");
		BufferedReader reader = new BufferedReader(new FileReader(filename));
	    Set<String> lines = new HashSet<String>(10000); // maybe should be bigger
	    String line;
	    while ((line = reader.readLine()) != null) {
	        	        lines.add(line);
	    }
	    reader.close();
	    BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
	    int i=1000;
	    for (String unique : lines) {
	    	//System.out.println(unique);
	    	writer.write(unique+i+"; )");
	        i++;
	        writer.newLine();
	    }
	    writer.close();
	}

	
}

