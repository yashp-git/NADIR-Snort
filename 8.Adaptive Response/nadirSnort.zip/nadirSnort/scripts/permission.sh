#!/bin/bash
sudo chmod -R a+rwx ~/.eclipse
sudo chmod -R a+rwx ~/workspace
sudo chmod -R 777 ~/workspace/*
