package nyit.csci.nadir.yash ;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.Map;

import javax.print.attribute.standard.DateTimeAtCompleted;

import java.awt.Frame;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.jnetpcap.Pcap;
import org.jnetpcap.nio.JMemory;
import org.jnetpcap.packet.JFlow;
import org.jnetpcap.packet.JFlowKey;
import org.jnetpcap.packet.JFlowMap;
import org.jnetpcap.packet.JHeader;
import org.jnetpcap.packet.JMemoryPacket;
import org.jnetpcap.packet.JPacket;
import org.jnetpcap.packet.JPacketHandler;
import org.jnetpcap.packet.JScanner;
import org.jnetpcap.packet.Payload;
import org.jnetpcap.packet.PcapPacket;
import org.jnetpcap.packet.PcapPacketHandler;
import org.jnetpcap.packet.format.FormatUtils;
import org.jnetpcap.protocol.lan.Ethernet;
import org.jnetpcap.protocol.network.Ip4;
import org.jnetpcap.protocol.tcpip.Http;
import org.jnetpcap.protocol.tcpip.Http.Request;
import org.jnetpcap.protocol.tcpip.Http.Response;
import org.jnetpcap.protocol.tcpip.Tcp;
import org.jnetpcap.protocol.tcpip.Udp;
import org.jnetpcap.protocol.voip.Sip.ContentType;

public class pcapParser {
	public static void main(String[] args) throws Exception {
			
		String name ="snort.log.1425823374";

		String csvFile = "D:\\Extract_csv\\raw_csv\\"+name+".csv";
		FileWriter cwriter = new FileWriter(csvFile);
		
		final String FILENAME = "D:\\log\\"+name;
		final StringBuilder errbuf = new StringBuilder();
		
       		
		final Pcap pcap = Pcap.openOffline(FILENAME, errbuf);
		
		if (pcap == null) {
			System.err.println(errbuf); // Error is stored in errbuf if any
			return;
		}
		else{
			//CSVUtils.writeLine(cwriter, Arrays.asList("PACKET_TYPE","FRAME","TIMESTAMP","WIRELEN","ETHER_OFFSET","ETHER_LENGTH","ETHER_DEST","ETHER_SOURCE","ETHER_TYPE","IP_OFFSET","IP_LENGTH","IP_VER","IP_HLEN","IP_FLAG","IP_TYPE","IP_CHECKSUM","IP_DEST","IP_SOURCE","TCP_OFFSET","TCP_LENGTH","DST_PORT","SOURCE_PORT","TCP_SEQ","TCP_ACK","TCP_HLEN","TCP_RESERVED","TCP_FIN","TCP_SYN","TCP_RST","TCP_PSH","TCP_ACK","TCP_URG","TCP_ECE","TCP_CWR","TCP_WINDOW","TCP_CHECKSUM","TCP_URGENT","MSS_OFFSET","MSS_LENGTH","MSS_CODE","MSS","WIN_OFFSET","WIN_LENGTH","WIN_CODE","WIN_SCALE","TIME_OFFSET","TIME_CODE","TIME_LENGTH","TIME_TSVL","TIME_TSECR","HTTP_OFFSET","HTTP_LENGTH","HTTP_REQUEST","HTTP_RESPONSE","PAYLOAD_OFFSET","PAYLOAD_LENGTH","PAYLOAD_DATA"));
				
			pcap.loop(1000000000, new JPacketHandler<StringBuilder>() {
				
				
				final Ethernet  ether = new Ethernet();
				final Ip4 ip = new Ip4();
				final Tcp tcp = new Tcp();
				final Http http = new Http();
				final Udp udp = new Udp();
				final Payload payload = new Payload();
				
			
				@Override
				public void nextPacket(JPacket packet, StringBuilder errbuf) {
					
					String packet_num = packet.getFrameNumber()+"";
					long timestamp = packet.getCaptureHeader().timestampInMillis();
					String packet_timestamp = Long.toString(timestamp);
					String packet_wirelen = packet.getPacketWirelen()+"";
					
			//		System.out.println(packet.toString());					
					System.out.printf("frame # %s --> ", packet_num);
					//System.out.println(packet.hasHeader(ip));
					//System.out.println(packet.hasHeader(http));
					//System.out.println(packet.toString());
					
					
						
					//System.out.println(packet.toString());
					if (packet.hasHeader(Ip4.ID)){
					//tcp header
						if(packet.hasHeader(ip) && packet.hasHeader(tcp) && packet.hasHeader(http)){
							System.out.println("HTTP-PKT");							
							packet.getHeader(ether);
							packet.getHeader(ip);
							packet.getHeader(tcp);
							packet.getHeader(http);
						
							
							//ETHERNET header
							String ether_offset = ether.getOffset()+"";
							String ether_length = ether.getLength()+"";
							String ether_dest = FormatUtils.mac(ether.destination())+"";
							String ether_source = FormatUtils.mac(ether.source())+"";
							String ether_type = ether.type()+"";
							
							//Ip4 header
							String ip4_offset = ip.getOffset()+"";
							String ip4_length = ip.getLength()+"";
							String ip4_ver = ip.version()+"";
							String ip4_hlen = ip.hlen()+"";
							String ip4_flag = ip.flags()+"";
							String ip4_type = ip.type()+"";
							String ip4_checksum = ip.checksum()+"";
							String ip4_source = tcpEndPointStr(ip.source())+"";
							String ip4_dest = tcpEndPointStr(ip.destination())+"";
							
							//TCP header
							String tcp_offset = tcp.getOffset()+"";
							String tcp_length = tcp.getLength()+"";
							String tcp_destport = tcp.destination()+"";
							String tcp_sourceport = tcp.source()+"";
							String tcp_seq = tcp.seq()+"";
							String tcp_ack1 = tcp.ack()+"";
							String tcp_hlen = tcp.hlen()+"";
							String tcp_reserved = tcp.reserved()+"";
							//flags
							String tcp_fin = tcp.flags_FIN()+"";
							String tcp_syn = tcp.flags_SYN()+"";
							String tcp_rst = tcp.flags_RST()+"";
							String tcp_psh = tcp.flags_PSH()+"";
							String tcp_ack = tcp.flags_ACK()+"";
							String tcp_urg = tcp.flags_URG()+"";
							String tcp_ece = tcp.flags_ECE()+"";
							String tcp_cwr = tcp.flags_CWR()+"";
							//end
							String tcp_window = tcp.window()+"";
							String tcp_checksum = tcp.checksum()+ "";
							String tcp_urgent = tcp.urgent()+"";
							
							String mss_offset="",mss_length = "",mss_code="",mss_m="",win_offset="",win_length="",win_code="",win_scale="",time_code ="",time_offset="",time_tsval = "",time_tsecr="",time_length="";
							for (JHeader subheader : tcp.getSubHeaders()) {
								if (subheader instanceof Tcp.MSS) {
			                        Tcp.MSS mss = (Tcp.MSS) subheader;
			                        mss_offset = mss.getOffset()+"";
			                        mss_length = mss.length()+"";
			                        mss_code = mss.code()+"";
			                        mss_m = mss.mss()+"";
			                    }
								if (subheader instanceof Tcp.WindowScale) {
			                        Tcp.WindowScale win = (Tcp.WindowScale) subheader;
			                        win_offset = win.getOffset()+"";
			                        win_length = win.length()+"";
			                        win_code =  win.code()+"";
			                        win_scale = win.scale()+"";
			                    }
								if (subheader instanceof Tcp.Timestamp) {
			                        Tcp.Timestamp time = (Tcp.Timestamp) subheader;
			                        time_code = time.code()+"";
			                        time_offset = time.getOffset()+"";
			                        time_length = time.length()+"";
			                        time_tsval = time.tsval()+"";
			                        time_tsecr = time.tsecr()+"";
			                    }
							}
							//HTTP header
							String http_offset = http.getOffset()+"";
							String http_length = http.getLength()+"";
							
							String req_method = http.fieldValue(Request.RequestMethod);  
			                String req_url = http.fieldValue(Request.RequestUrl);  
			                String req_ver = http.fieldValue(Request.RequestVersion);  
			                String req_host = http.fieldValue(Request.Host);
			                String req_user = http.fieldValue(Request.User_Agent);
			                String req_accept = http.fieldValue(Request.Accept);
			                String req_lan = http.fieldValue(Request.Accept_Language);
			                String req_encode = http.fieldValue(Request.Accept_Encoding);
			                String req_cookie = http.fieldValue(Request.Cookie);
			                String req_connection = http.fieldValue(Request.Connection);
			                String req_cache = http.fieldValue(Request.Cache_Control);
			                String req_date = http.fieldValue(Request.Date);
			               
			                String res_code = http.fieldValue(Response.ResponseCode);
			                String res_msg = http.fieldValue(Response.ResponseCodeMsg);
			                String res_server = http.fieldValue(Response.Server);
			                String res_acc = http.fieldValue(Response.Accept_Ranges);
			                String res_con = http.fieldValue(Response.Content_Length);
			                String res_cache = http.fieldValue(Response.Cache_Control);
			                String res_expire = http.fieldValue(Response.Expires);
			               
			                String http_req = (req_method+req_url+req_ver+req_host+req_user+req_accept+req_lan+req_encode+req_cookie+req_connection+req_cache+req_date).replaceAll(",", "//");
			                String http_res = (res_code+res_msg+res_server+res_acc+res_cache+res_expire).replaceAll(",", "//");
							
			                String payload_offset = "";
							String payload_length = "";
							String payload_data = "";
							
							if(packet.hasHeader(payload)){
							packet.getHeader(payload);
							//Payload header
							payload_offset = payload.getOffset()+"";
							payload_length = payload.getPayloadLength()+"";
							payload_data = payload.toHexdump().replace("\n", "\t").replace(",", "//");
							//System.out.println(payload_data);
							}
							
							
							String http_pkt = http.toString()+"";
							//System.out.println(http_pkt);
							
							try {
								CSVUtils.writeLine(cwriter, Arrays.asList("HTTP",packet_num,packet_timestamp,packet_wirelen,ether_offset,ether_length,ether_dest,ether_source,ether_type,ip4_offset,ip4_length,ip4_ver,ip4_hlen,ip4_flag,ip4_type,ip4_checksum,ip4_dest,ip4_source,tcp_offset,tcp_length,tcp_destport,tcp_sourceport,tcp_seq,tcp_ack1,tcp_hlen,tcp_reserved,tcp_fin,tcp_syn,tcp_rst,tcp_psh,tcp_ack,tcp_urg,tcp_ece,tcp_cwr,tcp_window,tcp_checksum,tcp_urgent,mss_offset,mss_length,mss_code,mss_m,win_offset,win_length,win_code,win_scale,time_offset,time_code,time_length,time_tsval,time_tsecr,http_offset,http_length,http_req,http_res,payload_offset,payload_length,payload_data));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}else if(packet.hasHeader(ip) && packet.hasHeader(tcp) && !packet.hasHeader(http)){
							System.out.println("TCP-PKT");
							packet.getHeader(ether);
							packet.getHeader(ip);
							packet.getHeader(tcp);
							
							//ETHERNET header
							String ether_offset = ether.getOffset()+"";
							String ether_length = ether.getLength()+"";
							String ether_dest = FormatUtils.mac(ether.destination())+"";
							String ether_source = FormatUtils.mac(ether.source())+"";
							String ether_type = ether.type()+"";
							
							//Ip4 header
							String ip4_offset = ip.getOffset()+"";
							String ip4_length = ip.getLength()+"";
							String ip4_ver = ip.version()+"";
							String ip4_hlen = ip.hlen()+"";
							String ip4_flag = ip.flags()+"";
							String ip4_type = ip.type()+"";
							String ip4_checksum = ip.checksum()+"";
							String ip4_source = tcpEndPointStr(ip.source())+"";
							String ip4_dest = tcpEndPointStr(ip.destination())+"";
							
							//TCP header
							String tcp_offset = tcp.getOffset()+"";
							String tcp_length = tcp.getLength()+"";
							String tcp_destport = tcp.destination()+"";
							String tcp_sourceport = tcp.source()+"";
							String tcp_seq = tcp.seq()+"";
							String tcp_ack1 = tcp.ack()+"";
							String tcp_hlen = tcp.hlen()+"";
							String tcp_reserved = tcp.reserved()+"";
							
							//flags
							String tcp_fin = tcp.flags_FIN()+"";
							String tcp_syn = tcp.flags_SYN()+"";
							String tcp_rst = tcp.flags_RST()+"";
							String tcp_psh = tcp.flags_PSH()+"";
							String tcp_ack = tcp.flags_ACK()+"";
							String tcp_urg = tcp.flags_URG()+"";
							String tcp_ece = tcp.flags_ECE()+"";
							String tcp_cwr = tcp.flags_CWR()+"";
							//end
							
							String tcp_window = tcp.window()+"";
							String tcp_checksum = tcp.checksum()+ "";
							String tcp_urgent = tcp.urgent()+"";
							
							String mss_offset="",mss_length = "",mss_code="",mss_m="",win_offset="",win_length="",win_code="",win_scale="",time_code ="",time_offset="",time_tsval = "",time_tsecr="",time_length="";
							for (JHeader subheader : tcp.getSubHeaders()) {
								if (subheader instanceof Tcp.MSS) {
			                        Tcp.MSS mss = (Tcp.MSS) subheader;
			                        mss_offset = mss.getOffset()+"";
			                        mss_length = mss.length()+"";
			                        mss_code = mss.code()+"";
			                        mss_m = mss.mss()+"";
			                    }
								if (subheader instanceof Tcp.WindowScale) {
			                        Tcp.WindowScale win = (Tcp.WindowScale) subheader;
			                        win_offset = win.getOffset()+"";
			                        win_length = win.length()+"";
			                        win_code =  win.code()+"";
			                        win_scale = win.scale()+"";
			                    }
								if (subheader instanceof Tcp.Timestamp) {
			                        Tcp.Timestamp time = (Tcp.Timestamp) subheader;
			                        time_code = time.code()+"";
			                        time_offset = time.getOffset()+"";
			                        time_length = time.length()+"";
			                        time_tsval = time.tsval()+"";
			                        time_tsecr = time.tsecr()+"";
			                    }
							}
							
							String payload_offset = "";
							String payload_length = "";
							String payload_data = "";
						
							if(packet.hasHeader(payload)){
								packet.getHeader(payload);
								//Payload header
								payload_offset = payload.getOffset()+"";
								payload_length = payload.getPayloadLength()+"";
								payload_data = payload.toHexdump().replace("\n", "\t").replace(",", "//");
								//System.out.println(payload_data);
								}
														
							String tcp_pkt = tcp.toString()+"";
							//System.out.println(tcp_pkt);
							
							
							try {
								CSVUtils.writeLine(cwriter, Arrays.asList("TCP",packet_num,packet_timestamp,packet_wirelen,ether_offset,ether_length,ether_dest,ether_source,ether_type,ip4_offset,ip4_length,ip4_ver,ip4_hlen,ip4_flag,ip4_type,ip4_checksum,ip4_dest,ip4_source,tcp_offset,tcp_length,tcp_destport,tcp_sourceport,tcp_seq,tcp_ack1,tcp_hlen,tcp_reserved,tcp_fin,tcp_syn,tcp_rst,tcp_psh,tcp_ack,tcp_urg,tcp_ece,tcp_cwr,tcp_window,tcp_checksum,tcp_urgent,mss_offset,mss_length,mss_code,mss_m,win_offset,win_length,win_code,win_scale,time_offset,time_code,time_length,time_tsval,time_tsecr,"","","","",payload_offset,payload_length,payload_data));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}else if(packet.hasHeader(ip) && packet.hasHeader(udp)){
							System.out.println("UDP-PKT");
							packet.getHeader(ether);
							packet.getHeader(ip);
							packet.getHeader(udp);
							
							//ETHERNET header
							String ether_offset = ether.getOffset()+"";
							String ether_length = ether.getLength()+"";
							String ether_dest = FormatUtils.mac(ether.destination())+"";
							String ether_source = FormatUtils.mac(ether.source())+"";
							String ether_type = ether.type()+"";
							
							//Ip4 header
							String ip4_offset = ip.getOffset()+"";
							String ip4_length = ip.getLength()+"";
							String ip4_ver = ip.version()+"";
							String ip4_hlen = ip.hlen()+"";
							String ip4_flag = ip.flags()+"";
							String ip4_type = ip.type()+"";
							String ip4_checksum = ip.checksum()+"";
							String ip4_source = tcpEndPointStr(ip.source())+"";
							String ip4_dest = tcpEndPointStr(ip.destination())+"";
							
							//UDP header
							String udp_offset = udp.getOffset()+"";
							String udp_length = udp.length()+"";
							String udp_checksum = udp.checksum()+"";
							String udp_hlen = udp.getHeaderLength()+"";
							String udp_destport = udp.destination()+"";
							String udp_sourceport = udp.source()+"";
														
							String payload_offset = "";
							String payload_length = "";
							String payload_data = "";
							
							if(packet.hasHeader(payload)){
								packet.getHeader(payload);
								//Payload header
								payload_offset = payload.getOffset()+"";
								payload_length = payload.getPayloadLength()+"";
								payload_data = payload.toHexdump().replace("\n", "\t").replace(",", "//");
								//System.out.println(payload_data);
							}
							
									
							
							String packet_Frame = packet.toString()+"";
							//System.out.println(packet.toString());
							
							try {
								CSVUtils.writeLine(cwriter,Arrays.asList("UDP",packet_num,packet_timestamp,packet_wirelen,ether_offset,ether_length,ether_dest,ether_source,ether_type,ip4_offset,ip4_length,ip4_ver,ip4_hlen,ip4_flag,ip4_type,ip4_checksum,ip4_dest,ip4_source,udp_offset,udp_length,udp_destport,udp_sourceport,"","",udp_hlen,"","","","","","","","","","","","","","","","","","","","","","","","","","","","","",payload_offset,payload_length,payload_data));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						else{
							System.out.println("UNKNOWN-PKT");
							//packet.getHeader(ether);
							//packet.getHeader(ip);
							//packet.getHeader(payload);
							
							try {
								CSVUtils.writeLine(cwriter, Arrays.asList("OTHER",packet_num,packet_timestamp,packet_wirelen,"","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					
						
					}
					else{
					//not tcp header
						System.out.println("NO-PKT");
						try {
							CSVUtils.writeLine(cwriter, Arrays.asList("OTHER",packet_num,packet_timestamp,packet_wirelen,"","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""));
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
				}

				private String tcpEndPointStr(byte addrBytes[]) {
					//ip address format
					String addr;
			        try {
			            addr = InetAddress.getByAddress(addrBytes).getHostAddress();
			        } catch (UnknownHostException ex) {
			            addr = "0.0.0.0";
			        }
			        return addr;

				}
			
		}, errbuf);
			
			pcap.close();
			cwriter.flush();
		    cwriter.close();
		    System.out.println("DONE !");
		}
		
	}
}